/**
 * PCAS Plugin - Options Script v2.0
 * 简化配置，自动识别 API 格式
 */

// ============================================================
// API 预设配置
// ============================================================
const API_PRESETS = {
  deepseek: {
    name: 'DeepSeek',
    url: 'https://api.deepseek.com/v1',
    format: 'openai',
    models: {
      normal: 'deepseek-chat',
      vision: 'deepseek-chat',
      think: 'deepseek-reasoner'
    }
  },
  mimo: {
    name: '小米 MiMo',
    url: 'https://api.xiaomimimo.com/anthropic/v1',
    format: 'mimo',
    models: {
      normal: 'mimo-v2.5',
      vision: 'mimo-v2.5',
      think: 'mimo-v2.5-pro'
    }
  },
  openai: {
    name: 'OpenAI',
    url: 'https://api.openai.com/v1',
    format: 'openai',
    models: {
      normal: 'gpt-4o-mini',
      vision: 'gpt-4o',
      think: 'gpt-4o'
    }
  },
  anthropic: {
    name: 'Anthropic Claude',
    url: 'https://api.anthropic.com',
    format: 'anthropic',
    models: {
      normal: 'claude-3-haiku-20240307',
      vision: 'claude-3-5-sonnet-20241022',
      think: 'claude-3-opus-20240229'
    }
  },
  moonshot: {
    name: '月之暗面',
    url: 'https://api.moonshot.cn/v1',
    format: 'openai',
    models: {
      normal: 'moonshot-v1-8k',
      vision: 'moonshot-v1-32k',
      think: 'moonshot-v1-128k'
    }
  },
  zhipu: {
    name: '智谱 AI',
    url: 'https://open.bigmodel.cn/api/paas/v4',
    format: 'openai',
    models: {
      normal: 'glm-4-flash',
      vision: 'glm-4v',
      think: 'glm-4'
    }
  },
  qwen: {
    name: '通义千问',
    url: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    format: 'openai',
    models: {
      normal: 'qwen-turbo',
      vision: 'qwen-vl-plus',
      think: 'qwen-max'
    }
  }
};

// ============================================================
// 初始化
// ============================================================
document.addEventListener('DOMContentLoaded', async () => {
  // DOM 元素
  const elements = {
    apiProvider: document.getElementById('apiProvider'),
    apiUrl: document.getElementById('apiUrl'),
    apiUrlHelp: document.getElementById('apiUrlHelp'),
    apiKey: document.getElementById('apiKey'),
    modelNormal: document.getElementById('modelNormal'),
    modelVision: document.getElementById('modelVision'),
    modelThink: document.getElementById('modelThink'),
    modelNormalHelp: document.getElementById('modelNormalHelp'),
    modelVisionHelp: document.getElementById('modelVisionHelp'),
    modelThinkHelp: document.getElementById('modelThinkHelp'),
    autoFill: document.getElementById('autoFill'),
    autoSearch: document.getElementById('autoSearch'),
    showFloatingButton: document.getElementById('showFloatingButton'),
    cacheEnabled: document.getElementById('cacheEnabled'),
    fillDelay: document.getElementById('fillDelay'),
    requestTimeout: document.getElementById('requestTimeout'),
    historyCount: document.getElementById('historyCount'),
    historyList: document.getElementById('historyList'),
    testResult: document.getElementById('testResult'),
    toast: document.getElementById('toast')
  };

  // 加载配置
  await loadConfig();
  await loadHistory();

  // 初始化标签页
  initTabs();

  // 初始化预设按钮
  initPresetButtons();

  // 初始化折叠面板
  initCollapsible();

  // 初始化密码切换
  initPasswordToggles();

  // ============================================================
  // API 服务切换
  // ============================================================
  elements.apiProvider.addEventListener('change', () => {
    const provider = elements.apiProvider.value;
    const preset = API_PRESETS[provider];

    if (preset && provider !== 'custom') {
      elements.apiUrl.value = preset.url;
      elements.modelNormal.placeholder = preset.models.normal;
      elements.modelVision.placeholder = preset.models.vision;
      elements.modelThink.placeholder = preset.models.think;
      elements.apiUrlHelp.textContent = `${preset.name} API 地址`;

      // 更新模型推荐提示
      updateModelHelp(provider);
    }
  });

  // ============================================================
  // 预设按钮
  // ============================================================
  function initPresetButtons() {
    document.querySelectorAll('.preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;

        // 更新选中状态
        document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // 应用预设
        if (preset !== 'custom') {
          elements.apiProvider.value = preset;
          elements.apiProvider.dispatchEvent(new Event('change'));
        }
      });
    });
  }

  // ============================================================
  // 测试连接
  // ============================================================
  document.getElementById('btnTestConnection').addEventListener('click', async () => {
    const btn = document.getElementById('btnTestConnection');
    btn.disabled = true;
    btn.textContent = '测试中...';
    elements.testResult.style.display = 'none';

    // 先保存配置
    await saveApiConfig();

    // 发送测试请求
    chrome.runtime.sendMessage({ type: 'API_TEST' }, (response) => {
      btn.disabled = false;
      btn.textContent = '🔌 测试连接';

      if (response?.data?.success) {
        showTestResult('success', '✅ 连接成功！');
      } else {
        showTestResult('error', `❌ ${response?.data?.message || response?.error || '连接失败'}`);
      }
    });
  });

  // ============================================================
  // 保存配置
  // ============================================================
  document.getElementById('btnSaveApi').addEventListener('click', async () => {
    await saveApiConfig();
    showToast('API 配置已保存', 'success');
  });

  document.getElementById('btnSaveModels').addEventListener('click', async () => {
    await saveModelConfig();
    showToast('模型设置已保存', 'success');
  });

  document.getElementById('btnSaveBehavior').addEventListener('click', async () => {
    await saveBehaviorConfig();
    showToast('行为设置已保存', 'success');
  });

  // ============================================================
  // 加载配置
  // ============================================================
  async function loadConfig() {
    const config = await getConfig([
      'apiProvider', 'apiUrl', 'apiKey',
      'modelNormal', 'modelVision', 'modelThink',
      'autoFill', 'autoSearch', 'showFloatingButton', 'cacheEnabled',
      'fillDelay', 'requestTimeout'
    ]);

    // API 配置
    elements.apiProvider.value = config.apiProvider || 'deepseek';
    elements.apiUrl.value = config.apiUrl || '';
    elements.apiKey.value = config.apiKey || '';

    // 触发 provider change 事件
    elements.apiProvider.dispatchEvent(new Event('change'));

    // 模型配置
    elements.modelNormal.value = config.modelNormal || '';
    elements.modelVision.value = config.modelVision || '';
    elements.modelThink.value = config.modelThink || '';

    // 行为配置
    elements.autoFill.checked = config.autoFill || false;
    elements.autoSearch.checked = config.autoSearch || false;
    elements.showFloatingButton.checked = config.showFloatingButton !== false;
    elements.cacheEnabled.checked = config.cacheEnabled !== false;
    elements.fillDelay.value = config.fillDelay || 300;
    elements.requestTimeout.value = config.requestTimeout || 30;
  }

  // ============================================================
  // 保存配置
  // ============================================================
  async function saveApiConfig() {
    const provider = elements.apiProvider.value;
    const preset = API_PRESETS[provider];

    await saveConfig({
      apiProvider: provider,
      apiFormat: preset ? preset.format : 'openai',
      apiUrl: elements.apiUrl.value.trim(),
      apiKey: elements.apiKey.value.trim()
    });
  }

  async function saveModelConfig() {
    const provider = elements.apiProvider.value;
    const preset = API_PRESETS[provider];

    // 获取模型值，如果为空则使用预设默认值
    const getOrDefault = (value, fallback) => value.trim() || fallback;

    await saveConfig({
      modelNormal: elements.modelNormal.value.trim() || (preset ? preset.models.normal : ''),
      modelVision: elements.modelVision.value.trim() || (preset ? preset.models.vision : ''),
      modelThink: elements.modelThink.value.trim() || (preset ? preset.models.think : '')
    });
  }

  async function saveBehaviorConfig() {
    await saveConfig({
      autoFill: elements.autoFill.checked,
      autoSearch: elements.autoSearch.checked,
      showFloatingButton: elements.showFloatingButton.checked,
      cacheEnabled: elements.cacheEnabled.checked,
      fillDelay: parseInt(elements.fillDelay.value) || 300,
      requestTimeout: parseInt(elements.requestTimeout.value) || 30
    });
  }

  // ============================================================
  // 更新模型帮助文本
  // ============================================================
  function updateModelHelp(provider) {
    const preset = API_PRESETS[provider];
    if (!preset) return;

    elements.modelNormalHelp.textContent = `推荐: ${preset.models.normal}`;
    elements.modelVisionHelp.textContent = `推荐: ${preset.models.vision}（需支持视觉）`;
    elements.modelThinkHelp.textContent = `推荐: ${preset.models.think}（推理能力强）`;
  }

  // ============================================================
  // 标签页切换
  // ============================================================
  function initTabs() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = item.dataset.tab;

        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');

        document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
        document.getElementById(`tab-${tabId}`).classList.add('active');
      });
    });
  }

  // ============================================================
  // 折叠面板
  // ============================================================
  function initCollapsible() {
    document.querySelectorAll('.toggle-collapse').forEach(toggle => {
      toggle.addEventListener('click', () => {
        const targetId = toggle.dataset.target;
        const content = document.getElementById(targetId);
        const card = toggle.closest('.card-collapsible');

        if (content.style.display === 'none') {
          content.style.display = 'block';
          card.classList.add('expanded');
        } else {
          content.style.display = 'none';
          card.classList.remove('expanded');
        }
      });
    });
  }

  // ============================================================
  // 密码切换
  // ============================================================
  function initPasswordToggles() {
    document.querySelectorAll('.toggle-password').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.dataset.target;
        const input = document.getElementById(targetId);
        if (input) {
          const type = input.type === 'password' ? 'text' : 'password';
          input.type = type;
          btn.textContent = type === 'password' ? '👁️' : '🙈';
        }
      });
    });
  }

  // ============================================================
  // 历史记录
  // ============================================================
  async function loadHistory() {
    const data = await getConfig(['history']);
    const history = data.history || [];

    elements.historyCount.textContent = `${history.length} 条记录`;

    if (history.length === 0) {
      elements.historyList.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">📋</span>
          <p>暂无历史记录</p>
        </div>
      `;
      return;
    }

    elements.historyList.innerHTML = history.slice(0, 50).map((item) => {
      const date = new Date(item.timestamp);
      const timeStr = date.toLocaleString('zh-CN');
      const typeLabel = item.type === 'vision' ? '📸 图像' : item.type === 'think' ? '🧠 深度' : '🔍 普通';
      return `
        <div class="history-item">
          <div class="history-question">
            <span class="history-type">${typeLabel}</span>
            ${escapeHtml(item.question || '未知题目')}
          </div>
          <div class="history-answer">答案: ${escapeHtml(item.answer || '未知')}</div>
          <div class="history-meta">
            <span>${timeStr}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  // 清空历史
  document.getElementById('btnClearHistory').addEventListener('click', async () => {
    if (confirm('确定要清空所有历史记录吗？')) {
      await saveConfig({ history: [] });
      await loadHistory();
      showToast('历史记录已清空', 'info');
    }
  });

  // 清空缓存
  document.getElementById('btnClearCache').addEventListener('click', async () => {
    if (confirm('确定要清空所有缓存吗？')) {
      await saveConfig({ answerCache: {} });
      showToast('缓存已清空', 'info');
    }
  });

  // ============================================================
  // 工具函数
  // ============================================================
  function getConfig(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function saveConfig(config) {
    return new Promise((resolve) => {
      chrome.storage.local.set(config, resolve);
    });
  }

  function showTestResult(type, message) {
    elements.testResult.style.display = 'block';
    elements.testResult.className = `test-result ${type}`;
    elements.testResult.textContent = message;
  }

  function showToast(message, type = 'info') {
    elements.toast.textContent = message;
    elements.toast.className = `toast show ${type}`;
    setTimeout(() => {
      elements.toast.classList.remove('show');
    }, 3000);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
});
