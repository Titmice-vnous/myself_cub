/**
 * PCAS Plugin - Popup Script
 * 弹出窗口的交互逻辑
 */

document.addEventListener('DOMContentLoaded', async () => {
  // ============================================================
  // DOM 元素
  // ============================================================
  const elements = {
    statusCard: document.getElementById('statusCard'),
    statusIcon: document.getElementById('statusIcon'),
    statusTitle: document.getElementById('statusTitle'),
    statusDesc: document.getElementById('statusDesc'),

    // 普通搜题
    btnAnalyzePage: document.getElementById('btnAnalyzePage'),
    btnAnalyzeSelected: document.getElementById('btnAnalyzeSelected'),

    // 图像分析
    btnVisionSelected: document.getElementById('btnVisionSelected'),
    btnVisionScreenshot: document.getElementById('btnVisionScreenshot'),

    // 深度思考
    btnThinkPage: document.getElementById('btnThinkPage'),
    btnThinkSelected: document.getElementById('btnThinkSelected'),

    // 设置
    apiMode: document.getElementById('apiMode'),
    autoFill: document.getElementById('autoFill'),
    autoSearch: document.getElementById('autoSearch'),
    showFloat: document.getElementById('showFloat'),
    statToday: document.getElementById('statToday'),
    statCache: document.getElementById('statCache'),
    statHistory: document.getElementById('statHistory'),
    linkSettings: document.getElementById('linkSettings'),
    linkHistory: document.getElementById('linkHistory'),
    linkHelp: document.getElementById('linkHelp')
  };

  // ============================================================
  // 初始化
  // ============================================================
  await loadConfig();
  await loadStats();

  // ============================================================
  // 事件绑定 - 普通搜题
  // ============================================================

  elements.btnAnalyzePage.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '分析中...', '正在分析当前页面题目');
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_PAGE', apiType: 'normal' }, (response) => {
        if (response?.success) {
          setStatus('success', '分析完成', '页面题目分析已完成');
          loadStats();
        } else {
          setStatus('error', '分析失败', '请确保页面已加载完成');
        }
      });
    }
  });

  elements.btnAnalyzeSelected.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '分析中...', '正在分析选中内容');
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'normal' }, (response) => {
        if (response?.success) {
          setStatus('success', '分析完成', '选中内容分析已完成');
          loadStats();
        } else {
          setStatus('error', '分析失败', '请先选中题目文本');
        }
      });
    }
  });

  // ============================================================
  // 事件绑定 - 图像分析
  // ============================================================

  elements.btnVisionSelected.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '图像分析中...', '正在分析选中内容');
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'vision' }, (response) => {
        if (response?.success) {
          setStatus('success', '分析完成', '图像分析已完成');
          loadStats();
        } else {
          setStatus('error', '分析失败', '请先选中题目文本');
        }
      });
    }
  });

  elements.btnVisionScreenshot.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '截图中...', '正在截取当前页面');
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
          format: 'png',
          quality: 80
        });

        setStatus('loading', '图像分析中...', '正在分析截图内容');

        chrome.runtime.sendMessage({
          type: 'API_SOLVE',
          apiType: 'vision',
          params: {
            mode: 'image',
            content: dataUrl,
            meta: { url: tab.url, title: tab.title }
          }
        }, (response) => {
          if (response?.data) {
            setStatus('success', '分析完成', `答案: ${response.data.answer}`);
            loadStats();
          } else {
            setStatus('error', '分析失败', response?.error || '请检查图像分析 API 配置');
          }
        });
      } catch (error) {
        setStatus('error', '截图失败', error.message);
      }
    }
  });

  // ============================================================
  // 事件绑定 - 深度思考
  // ============================================================

  elements.btnThinkPage.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '深度思考中...', '正在分析当前页面题目');
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_PAGE', apiType: 'think' }, (response) => {
        if (response?.success) {
          setStatus('success', '分析完成', '深度思考分析已完成');
          loadStats();
        } else {
          setStatus('error', '分析失败', '请确保页面已加载完成');
        }
      });
    }
  });

  elements.btnThinkSelected.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      setStatus('loading', '深度思考中...', '正在分析选中内容');
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'think' }, (response) => {
        if (response?.success) {
          setStatus('success', '分析完成', '深度思考分析已完成');
          loadStats();
        } else {
          setStatus('error', '分析失败', '请先选中题目文本');
        }
      });
    }
  });

  // ============================================================
  // 事件绑定 - 设置
  // ============================================================

  elements.apiMode.addEventListener('change', async () => {
    await saveConfig({ apiMode: elements.apiMode.value });
  });

  elements.autoFill.addEventListener('change', async () => {
    await saveConfig({ autoFill: elements.autoFill.checked });
  });

  elements.autoSearch.addEventListener('change', async () => {
    await saveConfig({ autoSearch: elements.autoSearch.checked });
    // 通知当前标签页的 content script 更新自动搜题状态
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, {
        type: elements.autoSearch.checked ? 'START_AUTO_SEARCH' : 'STOP_AUTO_SEARCH'
      });
    }
  });

  elements.showFloat.addEventListener('change', async () => {
    await saveConfig({ showFloatingButton: elements.showFloat.checked });
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: 'UPDATE_FLOATING_BUTTON' });
    }
  });

  elements.linkSettings.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  elements.linkHistory.addEventListener('click', async (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  elements.linkHelp.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://github.com/your-repo/pcas-plugin' });
  });

  // ============================================================
  // 辅助函数
  // ============================================================

  async function loadConfig() {
    const config = await getConfig(['apiMode', 'autoFill', 'autoSearch', 'showFloatingButton', 'apiUrl', 'visionApiUrl', 'thinkApiUrl']);

    elements.apiMode.value = config.apiMode || 'text';
    elements.autoFill.checked = config.autoFill || false;
    elements.autoSearch.checked = config.autoSearch || false;
    elements.showFloat.checked = config.showFloatingButton !== false;

    // 检查 API 配置
    const warnings = [];
    if (!config.apiUrl) warnings.push('普通搜题');
    if (!config.visionApiUrl) warnings.push('图像分析');
    if (!config.thinkApiUrl) warnings.push('深度思考');

    if (warnings.length > 0) {
      setStatus('warning', '未配置 API', `请先配置: ${warnings.join('、')}`);
    }
  }

  async function loadStats() {
    const data = await getConfig(['answerCache', 'history']);

    const cacheCount = Object.keys(data.answerCache || {}).length;
    elements.statCache.textContent = cacheCount;

    const historyCount = (data.history || []).length;
    elements.statHistory.textContent = historyCount;

    const today = new Date().toDateString();
    const todayCount = (data.history || []).filter(h => {
      return new Date(h.timestamp).toDateString() === today;
    }).length;
    elements.statToday.textContent = todayCount;
  }

  function setStatus(type, title, desc) {
    elements.statusCard.className = `status-card ${type}`;
    elements.statusTitle.textContent = title;
    elements.statusDesc.textContent = desc;

    switch (type) {
      case 'loading':
        elements.statusIcon.textContent = '⏳';
        break;
      case 'success':
        elements.statusIcon.textContent = '✅';
        break;
      case 'error':
        elements.statusIcon.textContent = '❌';
        break;
      case 'warning':
        elements.statusIcon.textContent = '⚠️';
        break;
      default:
        elements.statusIcon.textContent = '⚡';
    }

    if (type !== 'loading') {
      setTimeout(() => {
        setStatus('ready', '就绪', '点击下方按钮开始分析');
      }, 3000);
    }
  }

  function getConfig(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }

  function saveConfig(config) {
    return new Promise((resolve) => {
      chrome.storage.local.set(config, resolve);
    });
  }
});
