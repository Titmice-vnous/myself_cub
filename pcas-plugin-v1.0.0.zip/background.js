/**
 * PCAS Plugin - Background Service Worker
 * 处理跨域请求、消息中转、持久化配置
 */

// ============================================================
// 安装/更新事件
// ============================================================
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('[PCAS] 扩展已安装');
    // 初始化默认配置
    chrome.storage.local.set({
      // API 配置
      apiProvider: 'deepseek',
      apiFormat: 'openai',
      apiUrl: 'https://api.deepseek.com/v1',
      apiKey: '',
      // 模型配置
      modelNormal: 'deepseek-chat',
      modelVision: 'deepseek-chat',
      modelThink: 'deepseek-reasoner',
      // 其他设置
      disclaimerAccepted: false,
      autoFill: true,
      autoSearch: false,
      showFloatingButton: true,
      cacheEnabled: true,
      cacheExpireHours: 24,
      screenshotQuality: 0.8,
      maxContextLength: 2000,
      requestTimeout: 30000,
      retryCount: 2,
      retryDelay: 1000,
      fillDelay: 300,
      darkMode: false,
      answerCache: {},
      history: []
    });

    // 创建右键菜单
    createContextMenus();
  }

  if (details.reason === 'update') {
    console.log('[PCAS] 扩展已更新');
    createContextMenus();
  }
});

// ============================================================
// 右键菜单
// ============================================================
function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    // 普通搜题
    chrome.contextMenus.create({
      id: 'pcas-analyze-selection',
      title: 'PCAS:普通搜题（选中内容）',
      contexts: ['selection']
    });

    chrome.contextMenus.create({
      id: 'pcas-analyze-page',
      title: 'PCAS:普通搜题（当前页面）',
      contexts: ['page']
    });

    // 图像分析
    chrome.contextMenus.create({
      id: 'pcas-vision-selection',
      title: 'PCAS:图像分析（选中内容）',
      contexts: ['selection']
    });

    chrome.contextMenus.create({
      id: 'pcas-vision-screenshot',
      title: 'PCAS:图像分析（截图）',
      contexts: ['page', 'frame']
    });

    // 深度思考
    chrome.contextMenus.create({
      id: 'pcas-think-selection',
      title: 'PCAS:深度思考（选中内容）',
      contexts: ['selection']
    });

    chrome.contextMenus.create({
      id: 'pcas-think-page',
      title: 'PCAS:深度思考（当前页面）',
      contexts: ['page']
    });
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  switch (info.menuItemId) {
    // 普通搜题
    case 'pcas-analyze-selection':
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'normal' });
      break;
    case 'pcas-analyze-page':
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_PAGE', apiType: 'normal' });
      break;

    // 图像分析
    case 'pcas-vision-selection':
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'vision' });
      break;
    case 'pcas-vision-screenshot':
      captureAndSend(tab, 'vision');
      break;

    // 深度思考
    case 'pcas-think-selection':
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_SELECTED', apiType: 'think' });
      break;
    case 'pcas-think-page':
      chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_PAGE', apiType: 'think' });
      break;
  }
});

// ============================================================
// 消息处理
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    // API 请求转发（绕过 CORS）
    case 'API_SOLVE':
      handleApiSolve(message.params, message.apiType || 'normal')
        .then(data => sendResponse({ data }))
        .catch(error => sendResponse({ error: error.message }));
      return true;

    // 测试连接
    case 'API_TEST':
      handleApiTest(message.apiType || 'normal')
        .then(data => sendResponse({ data }))
        .catch(error => sendResponse({ error: error.message }));
      return true;

    // 截图
    case 'CAPTURE_TAB':
      captureTab(sender.tab)
        .then(imageData => sendResponse({ imageData }))
        .catch(error => sendResponse({ error: error.message }));
      return true;

    // 打开设置页面
    case 'OPEN_OPTIONS':
      chrome.runtime.openOptionsPage();
      return false;

    // 获取配置
    case 'GET_CONFIG':
      chrome.storage.local.get(message.keys || null, (result) => {
        sendResponse(result);
      });
      return true;

    // 保存配置
    case 'SET_CONFIG':
      chrome.storage.local.set(message.config, () => {
        sendResponse({ success: true });
      });
      return true;
  }
});

// ============================================================
// API 请求处理
// ============================================================

/**
 * 获取 API 配置
 */
async function getApiConfig(apiType) {
  const config = await getConfig([
    'apiFormat', 'apiUrl', 'apiKey',
    'modelNormal', 'modelVision', 'modelThink',
    'requestTimeout', 'retryCount', 'retryDelay'
  ]);

  const format = config.apiFormat || 'openai';
  const timeout = (config.requestTimeout || 30) * 1000; // 转换为毫秒
  const maxRetries = config.retryCount || 2;
  const retryDelay = config.retryDelay || 1000;

  // 根据任务类型获取模型
  let model;
  switch (apiType) {
    case 'vision':
      model = config.modelVision || config.modelNormal || 'deepseek-chat';
      break;
    case 'think':
      model = config.modelThink || config.modelNormal || 'deepseek-reasoner';
      break;
    default:
      model = config.modelNormal || 'deepseek-chat';
  }

  return {
    format: format,
    url: config.apiUrl,
    key: config.apiKey,
    model: model,
    timeout: apiType === 'think' ? timeout * 2 : timeout, // 深度思考超时翻倍
    maxRetries: maxRetries,
    retryDelay: retryDelay
  };
}

/**
 * 获取系统提示词
 */
function getSystemPrompt(apiType) {
  const today = new Date().toISOString().split('T')[0];

  switch (apiType) {
    case 'vision':
      return `You are PCAS, an AI assistant specialized in analyzing images and answering questions. Today is ${today}. Focus on identifying questions in images and providing accurate answers.`;
    case 'think':
      return `You are PCAS, an AI assistant specialized in deep analysis and problem solving. Today is ${today}. Provide detailed reasoning process before giving the final answer.`;
    default:
      return `You are PCAS, a quick and accurate question answering assistant. Today is ${today}. Give concise answers directly.`;
  }
}

/**
 * 构建提示词文本
 */
function buildPromptText(params, apiType) {
  const { content, options } = params;

  let prompt = '';

  if (apiType === 'vision') {
    prompt = '请仔细分析图片中的内容，识别出题目并给出答案。';
    if (content) {
      prompt += '\n\n补充信息：' + content;
    }
  } else if (apiType === 'think') {
    prompt = '请对以下题目进行深入分析，给出详细的解题思路和最终答案。\n\n';
    prompt += '## 题目\n' + content;
  } else {
    prompt = '请分析以下题目并给出答案。\n\n';
    prompt += '## 题目\n' + content;
  }

  if (options && options.length > 0) {
    prompt += '\n\n## 选项\n' + options.join('\n');
  }

  prompt += '\n\n## 回答格式\n';
  prompt += '- 单选题：只回答一个选项字母（如 A）\n';
  prompt += '- 多选题：回答所有正确选项字母，连续排列不分隔（如 AB、ACD）\n';
  prompt += '- 判断题：只回答选项字母（A=对/正确，B=错/错误）\n';
  prompt += '- 填空题：只回答填空答案，多个空用 | 分隔（如 答案1|答案2）\n';
  prompt += '- 编程题/简答题：直接给出完整的代码或文字答案，不要多余解释\n';
  prompt += '- 如需解释，用 | 分隔，如: B|因为xxx';

  return prompt;
}

/**
 * 解析 API 响应，提取答案
 */
function parseAnswer(responseText) {
  const parts = responseText.split('|');
  const answer = parts[0]?.trim() || '';
  const explanation = parts.slice(1).join('|').trim() || '';

  return { answer, explanation };
}

/**
 * 构建 OpenAI/DeepSeek 格式请求
 */
function buildOpenAIRequest(apiConfig, params, apiType) {
  const { model } = apiConfig;
  const prompt = buildPromptText(params, apiType);
  const systemPrompt = getSystemPrompt(apiType);

  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: prompt }
  ];

  // 如果有图片且是视觉模式，使用多模态格式
  if (params.imageData && apiType === 'vision') {
    messages[1].content = [
      {
        type: 'image_url',
        image_url: {
          url: params.imageData.startsWith('data:') ? params.imageData : `data:image/png;base64,${params.imageData}`
        }
      },
      { type: 'text', text: prompt }
    ];
  }

  return {
    url: apiConfig.url.replace(/\/$/, '') + '/chat/completions',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiConfig.key}`
    },
    body: {
      model: model,
      max_tokens: 2048,
      messages: messages
    }
  };
}

/**
 * 构建 MiMo 格式请求
 */
function buildMiMoRequest(apiConfig, params, apiType) {
  const { model } = apiConfig;
  const prompt = buildPromptText(params, apiType);
  const systemPrompt = getSystemPrompt(apiType);

  const contentBlocks = [];

  // 如果有图片且是视觉模式
  if (params.imageData && apiType === 'vision') {
    contentBlocks.push({
      type: 'image',
      source: {
        type: 'base64',
        media_type: 'image/png',
        data: params.imageData.replace(/^data:image\/\w+;base64,/, '')
      }
    });
  }

  contentBlocks.push({ type: 'text', text: prompt });

  const body = {
    model: model,
    max_tokens: 2048,
    system: systemPrompt,
    messages: [{ role: 'user', content: contentBlocks }]
  };

  // 深度思考模式启用 thinking
  if (apiType === 'think') {
    body.thinking = { type: 'enabled' };
    // 深度思考使用 pro 模型
    if (!model.includes('-pro')) {
      body.model = model + '-pro';
    }
  }

  return {
    url: apiConfig.url.replace(/\/$/, '') + '/messages',
    headers: {
      'Content-Type': 'application/json',
      'api-key': apiConfig.key
    },
    body: body
  };
}

/**
 * 构建 Anthropic 格式请求
 */
function buildAnthropicRequest(apiConfig, params, apiType) {
  const { model } = apiConfig;
  const prompt = buildPromptText(params, apiType);

  const contentBlocks = [];

  // 如果有图片且是视觉模式
  if (params.imageData && apiType === 'vision') {
    contentBlocks.push({
      type: 'image',
      source: {
        type: 'base64',
        media_type: 'image/png',
        data: params.imageData.replace(/^data:image\/\w+;base64,/, '')
      }
    });
  }

  contentBlocks.push({ type: 'text', text: prompt });

  return {
    url: apiConfig.url.replace(/\/$/, '') + '/messages',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiConfig.key,
      'anthropic-version': '2023-06-01'
    },
    body: {
      model: model,
      max_tokens: 2048,
      system: getSystemPrompt(apiType),
      messages: [{ role: 'user', content: contentBlocks }]
    }
  };
}

/**
 * 构建请求（根据格式）
 */
function buildRequest(apiConfig, params, apiType) {
  switch (apiConfig.format) {
    case 'mimo':
      return buildMiMoRequest(apiConfig, params, apiType);
    case 'anthropic':
      return buildAnthropicRequest(apiConfig, params, apiType);
    case 'openai':
    default:
      return buildOpenAIRequest(apiConfig, params, apiType);
  }
}

/**
 * 解析响应（根据格式）
 */
function parseResponse(data, format) {
  let responseText = '';
  let thinkingText = '';

  switch (format) {
    case 'openai':
      responseText = data.choices?.[0]?.message?.content || '';
      break;
    case 'mimo':
    case 'anthropic':
      // 遍历 content 数组，提取 text 和 thinking
      if (data.content && Array.isArray(data.content)) {
        for (const block of data.content) {
          if (block.type === 'text') {
            responseText = block.text || '';
          } else if (block.type === 'thinking') {
            thinkingText = block.thinking || '';
          }
        }
      }
      break;
    default:
      // 自动检测
      if (data.choices?.[0]?.message?.content) {
        responseText = data.choices[0].message.content;
      } else if (data.content && Array.isArray(data.content)) {
        for (const block of data.content) {
          if (block.type === 'text') {
            responseText = block.text || '';
          } else if (block.type === 'thinking') {
            thinkingText = block.thinking || '';
          }
        }
      } else if (typeof data === 'string') {
        responseText = data;
      } else {
        responseText = JSON.stringify(data);
      }
  }

  const result = parseAnswer(responseText);

  // 如果有思考过程，添加到解释中
  if (thinkingText) {
    result.thinking = thinkingText;
    if (!result.explanation) {
      result.explanation = thinkingText;
    }
  }

  return result;
}

/**
 * 发送 API 请求（带 429 限流处理）
 */
async function sendApiRequest(apiConfig, params, apiType) {
  if (!apiConfig.url) {
    throw new Error('请先在设置中配置 API 地址');
  }

  const { timeout, maxRetries, retryDelay, format } = apiConfig;
  const request = buildRequest(apiConfig, params, apiType);

  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      console.log(`[PCAS] 发送 API 请求 (尝试 ${attempt + 1}/${maxRetries + 1}):`, request.url);

      const response = await fetch(request.url, {
        method: 'POST',
        headers: request.headers,
        body: JSON.stringify(request.body),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      // 处理 429 限流错误
      if (response.status === 429) {
        const retryAfter = response.headers.get('Retry-After');
        const waitTime = retryAfter ? parseInt(retryAfter) * 1000 : (attempt + 1) * 3000;
        console.warn(`[PCAS] 请求被限流，等待 ${waitTime}ms 后重试`);

        if (attempt < maxRetries) {
          await sleep(waitTime);
          continue; // 重试
        } else {
          throw new Error('API 请求过于频繁，请稍后再试');
        }
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => 'Unknown error');
        console.error('[PCAS] API 错误响应:', errorText);
        throw new Error(`API 请求失败 (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      const { answer, explanation, thinking } = parseResponse(data, format);

      return {
        success: true,
        answer: answer,
        explanation: explanation,
        thinking: thinking,
        target_selector: null,
        raw: data
      };

    } catch (error) {
      lastError = error;

      if (error.name === 'AbortError') {
        lastError = new Error(`API 请求超时 (${timeout}ms)`);
      }

      console.error(`[PCAS] API 请求失败 (尝试 ${attempt + 1}/${maxRetries + 1}):`, error.message);

      // 如果是限流错误，等待更长时间
      if (error.message.includes('429') || error.message.includes('频繁')) {
        const waitTime = (attempt + 1) * 3000;
        if (attempt < maxRetries) {
          await sleep(waitTime);
          continue;
        }
      }

      if (attempt < maxRetries) {
        await sleep(retryDelay * (attempt + 1));
      }
    }
  }

  throw lastError;
}

/**
 * 处理 API 搜题请求
 */
async function handleApiSolve(params, apiType = 'normal') {
  const apiConfig = await getApiConfig(apiType);
  return sendApiRequest(apiConfig, params, apiType);
}

/**
 * 测试 API 连接
 */
async function handleApiTest(apiType = 'normal') {
  const apiConfig = await getApiConfig(apiType);

  if (!apiConfig.url) {
    return { success: false, message: '请先配置 API 地址' };
  }

  const { format } = apiConfig;

  try {
    let request;

    // 构建测试请求
    const testParams = { content: 'Hi', options: [] };

    switch (format) {
      case 'openai':
        request = {
          url: apiConfig.url.replace(/\/$/, '') + '/chat/completions',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiConfig.key}`
          },
          body: {
            model: apiConfig.model,
            max_tokens: 10,
            messages: [{ role: 'user', content: 'Hi' }]
          }
        };
        break;
      case 'mimo':
        request = {
          url: apiConfig.url.replace(/\/$/, '') + '/messages',
          headers: {
            'Content-Type': 'application/json',
            'api-key': apiConfig.key
          },
          body: {
            model: apiConfig.model,
            max_tokens: 10,
            system: 'You are a helpful assistant.',
            messages: [{ role: 'user', content: [{ type: 'text', text: 'Hi' }] }]
          }
        };
        break;
      case 'anthropic':
        request = {
          url: apiConfig.url.replace(/\/$/, '') + '/messages',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': apiConfig.key,
            'anthropic-version': '2023-06-01'
          },
          body: {
            model: apiConfig.model,
            max_tokens: 10,
            system: 'You are a helpful assistant.',
            messages: [{ role: 'user', content: [{ type: 'text', text: 'Hi' }] }]
          }
        };
        break;
      default:
        throw new Error('不支持的 API 格式');
    }

    console.log('[PCAS] 测试连接请求:', request.url);
    console.log('[PCAS] API 格式:', format);

    const response = await fetch(request.url, {
      method: 'POST',
      headers: request.headers,
      body: JSON.stringify(request.body),
      signal: AbortSignal.timeout(15000)
    });

    if (response.ok) {
      return { success: true, message: '连接成功' };
    } else {
      const errorText = await response.text().catch(() => '');
      console.error('[PCAS] API 错误响应:', errorText);
      return { success: false, message: `服务器返回 ${response.status}: ${errorText}` };
    }
  } catch (error) {
    return { success: false, message: `连接失败: ${error.message}` };
  }
}

// ============================================================
// 截图功能
// ============================================================
async function captureTab(tab) {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'png',
      quality: 80
    });
    return dataUrl;
  } catch (error) {
    throw new Error(`截图失败: ${error.message}`);
  }
}

async function captureAndSend(tab, apiType = 'vision') {
  try {
    const imageData = await captureTab(tab);
    // 发送到 content script 进行分析
    chrome.tabs.sendMessage(tab.id, {
      type: 'SCREENSHOT_ANALYZE',
      imageData,
      apiType
    });
  } catch (error) {
    console.error('[PCAS] 截图失败:', error);
  }
}

// ============================================================
// 工具函数
// ============================================================
function getConfig(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// 定时清理过期缓存
// ============================================================
async function cleanupExpiredCache() {
  const config = await getConfig(['answerCache', 'cacheExpireHours']);
  const cache = config.answerCache || {};
  const expireMs = (config.cacheExpireHours || 24) * 60 * 60 * 1000;
  const now = Date.now();
  let changed = false;

  for (const key of Object.keys(cache)) {
    if (now - cache[key].timestamp > expireMs) {
      delete cache[key];
      changed = true;
    }
  }

  if (changed) {
    chrome.storage.local.set({ answerCache: cache });
  }
}

// 每小时清理一次过期缓存
chrome.alarms.create('cleanupCache', { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'cleanupCache') {
    cleanupExpiredCache();
  }
});
