/**
 * PCAS Plugin - Content Script v2.0
 * 注入到网页中，负责 DOM 解析、截图、答案填充
 */

(function () {
  'use strict';

  // 防止重复注入
  if (window.__pcas_loaded) return;
  window.__pcas_loaded = true;

  // 检查依赖是否加载
  console.log('[PCAS] 初始化中...');
  console.log('[PCAS] PCAS_Storage:', typeof PCAS_Storage);
  console.log('[PCAS] PCAS_API:', typeof PCAS_API);

  if (typeof PCAS_Storage === 'undefined') {
    console.error('[PCAS] PCAS_Storage 未定义，请检查 lib/storage.js');
    return;
  }
  if (typeof PCAS_API === 'undefined') {
    console.error('[PCAS] PCAS_API 未定义，请检查 lib/api.js');
    return;
  }

  // 终止控制器
  let abortController = null;

  // ============================================================
  // UI 模块
  // ============================================================
  const UI = {
    /** 初始化 UI */
    async init() {
      this.createFloatingPanel();
      this.createAnswerPopup();
      this.createOverlay();
      this.createToast();
      this.createHistoryPanel();
      this.createDisclaimer();
      this.createFeedbackPanel();
      this.bindEvents();

      // 检查免责声明是否已同意
      const config = await PCAS_Storage.getConfig(['disclaimerAccepted']);
      if (!config.disclaimerAccepted) {
        document.getElementById('pcas-disclaimer').classList.add('pcas-show');
        // 禁用悬浮球直到同意
        const mainBtn = document.getElementById('pcas-main-btn');
        if (mainBtn) mainBtn.style.pointerEvents = 'none';
      }
    },

    /** 创建悬浮面板 */
    createFloatingPanel() {
      const panel = document.createElement('div');
      panel.id = 'pcas-panel';
      panel.innerHTML = `
        <!-- 主按钮 -->
        <button id="pcas-main-btn" title="PCAS 个人配置API搜题">
          <span class="pcas-btn-icon">🔍</span>
        </button>

        <!-- 状态指示器 -->
        <div id="pcas-status" class="pcas-status-hidden">
          <div class="pcas-status-spinner"></div>
          <span class="pcas-status-text">处理中...</span>
          <button id="pcas-stop-btn" title="终止">⏹</button>
        </div>

        <!-- 菜单 -->
        <div id="pcas-menu">
          <div class="pcas-menu-header">
            <span class="pcas-menu-title">个人配置API搜题插件</span>
            <span class="pcas-menu-version">v2.0</span>
          </div>

          <div class="pcas-menu-body">
            <!-- 快捷操作 -->
            <div class="pcas-quick-actions">
              <button class="pcas-quick-btn" data-action="analyze-selected" data-api="normal" title="普通搜题">
                <span>🔍</span>
                <span>搜题</span>
              </button>
              <button class="pcas-quick-btn vision" data-action="vision-selected" data-api="vision" title="图像分析">
                <span>📸</span>
                <span>图像</span>
              </button>
              <button class="pcas-quick-btn think" data-action="think-selected" data-api="think" title="深度思考">
                <span>🧠</span>
                <span>深度</span>
              </button>
              <button class="pcas-quick-btn" data-action="analyze-page" data-api="normal" title="分析整个页面">
                <span>📄</span>
                <span>页面</span>
              </button>
            </div>

            <div class="pcas-menu-divider"></div>

            <!-- 更多功能 -->
            <div class="pcas-menu-section">
              <button class="pcas-menu-item" data-action="vision-screenshot" data-api="vision">
                <span class="pcas-item-icon">📷</span>
                <span class="pcas-item-text">截图识别</span>
                <span class="pcas-item-key">Alt+S</span>
              </button>
              <button class="pcas-menu-item" data-action="think-page" data-api="think">
                <span class="pcas-item-icon">🧠</span>
                <span class="pcas-item-text">深度分析页面</span>
              </button>
              <button class="pcas-menu-item" data-action="auto-fill-all">
                <span class="pcas-item-icon">✨</span>
                <span class="pcas-item-text">自动填充所有</span>
              </button>
            </div>

            <div class="pcas-menu-divider"></div>

            <div class="pcas-menu-section">
              <button class="pcas-menu-item" data-action="toggle-auto-search" id="pcas-auto-search-btn">
                <span class="pcas-item-icon">🔄</span>
                <span class="pcas-item-text">自动搜题</span>
                <span class="pcas-item-toggle" id="pcas-auto-search-toggle">OFF</span>
              </button>
              <button class="pcas-menu-item" data-action="show-history">
                <span class="pcas-item-icon">📋</span>
                <span class="pcas-item-text">历史记录</span>
                <span class="pcas-item-badge" id="pcas-history-count">0</span>
              </button>
              <button class="pcas-menu-item" data-action="settings">
                <span class="pcas-item-icon">⚙️</span>
                <span class="pcas-item-text">设置</span>
              </button>
              <button class="pcas-menu-item" data-action="feedback">
                <span class="pcas-item-icon">💬</span>
                <span class="pcas-item-text">问题反馈</span>
              </button>
            </div>
          </div>

          <div class="pcas-menu-footer">
            <span>Ctrl+Shift+S 搜题 | Esc 关闭</span>
          </div>
        </div>
      `;
      document.body.appendChild(panel);
    },

    /** 创建答案弹窗 */
    createAnswerPopup() {
      const popup = document.createElement('div');
      popup.id = 'pcas-answer-popup';
      popup.innerHTML = `
        <div class="pcas-popup-header">
          <div class="pcas-popup-title">
            <span class="pcas-popup-icon">🎯</span>
            <h3 id="pcas-popup-title-text">搜题结果</h3>
          </div>
          <button class="pcas-popup-close">✕</button>
        </div>
        <div class="pcas-popup-body">
          <div class="pcas-answer-section">
            <div class="pcas-answer-label">答案</div>
            <div class="pcas-answer-text" id="pcas-answer-text"></div>
          </div>
          <div class="pcas-explanation-section" id="pcas-explanation-section" style="display:none">
            <div class="pcas-answer-label">解析</div>
            <div class="pcas-explanation" id="pcas-explanation"></div>
          </div>
          <div class="pcas-thinking-section" id="pcas-thinking-section" style="display:none">
            <div class="pcas-answer-label">💭 思考过程</div>
            <div class="pcas-thinking" id="pcas-thinking"></div>
          </div>
          <div class="pcas-popup-actions">
            <button class="pcas-btn pcas-btn-secondary" id="pcas-btn-copy">📋 复制</button>
            <button class="pcas-btn pcas-btn-secondary" id="pcas-btn-cancel">取消</button>
            <button class="pcas-btn pcas-btn-primary" id="pcas-btn-fill">✨ 填充答案</button>
          </div>
        </div>
      `;
      document.body.appendChild(popup);
    },

    /** 创建遮罩层 */
    createOverlay() {
      const overlay = document.createElement('div');
      overlay.id = 'pcas-overlay';
      document.body.appendChild(overlay);
    },

    /** 创建 Toast */
    createToast() {
      const toast = document.createElement('div');
      toast.id = 'pcas-toast';
      document.body.appendChild(toast);
    },

    /** 创建免责声明弹窗 */
    createDisclaimer() {
      const modal = document.createElement('div');
      modal.id = 'pcas-disclaimer';
      modal.innerHTML = `
        <div class="pcas-disclaimer-box">
          <div class="pcas-disclaimer-header">
            <span class="pcas-disclaimer-icon">📜</span>
            <h3>PCAS Plugin 免责声明</h3>
          </div>
          <div class="pcas-disclaimer-body">
            <div class="pcas-disclaimer-content">
              <h4>一、服务说明</h4>
              <p>PCAS Plugin（以下简称"本插件"）是一款浏览器扩展工具，通过调用第三方 AI API 接口为用户提供题目分析与答案参考服务。</p>

              <h4>二、免责声明</h4>
              <ol>
                <li><strong>学习辅助用途</strong>：本插件仅供学习辅助、课后复习、知识巩固使用，使用者应遵守所在学校或机构的相关规定。</li>
                <li><strong>答案准确性</strong>：本插件依赖第三方 AI 模型生成答案，答案的准确性和完整性不作保证。用户应自行判断答案的正确性。</li>
                <li><strong>非作弊工具</strong>：本插件不是作弊工具。使用者应自觉遵守考试纪律和学术诚信规范，不得在正式考试、考核中使用本插件。</li>
                <li><strong>责任自负</strong>：因使用本插件而产生的任何后果（包括但不限于学业处分、账号封禁等），由使用者自行承担，开发者不承担任何责任。</li>
                <li><strong>API 费用</strong>：本插件本身免费，但调用的第三方 API 可能产生费用，由用户自行承担。</li>
                <li><strong>数据安全</strong>：本插件不会收集或上传用户的个人信息和答题数据。题目文本仅作为 API 请求内容发送至用户自行配置的 AI 服务。</li>
              </ol>

              <h4>三、使用条件</h4>
              <p>使用本插件即表示您已阅读并同意上述条款。如不同意，请勿使用本插件。</p>
            </div>
            <div class="pcas-disclaimer-actions">
              <label class="pcas-disclaimer-check">
                <input type="checkbox" id="pcas-disclaimer-checkbox">
                <span>我已阅读并同意以上免责声明</span>
              </label>
              <button class="pcas-disclaimer-btn" id="pcas-disclaimer-accept" disabled>确认并开始使用</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      // 勾选框联动按钮
      const checkbox = modal.querySelector('#pcas-disclaimer-checkbox');
      const acceptBtn = modal.querySelector('#pcas-disclaimer-accept');
      checkbox.addEventListener('change', () => {
        acceptBtn.disabled = !checkbox.checked;
        if (checkbox.checked) {
          acceptBtn.classList.add('pcas-disclaimer-btn-active');
        } else {
          acceptBtn.classList.remove('pcas-disclaimer-btn-active');
        }
      });

      // 确认按钮
      acceptBtn.addEventListener('click', async () => {
        if (!checkbox.checked) return;
        await PCAS_Storage.setConfig({ disclaimerAccepted: true });
        modal.classList.remove('pcas-show');
        setTimeout(() => modal.remove(), 300);
        // 重新启用悬浮球
        const mainBtn = document.getElementById('pcas-main-btn');
        if (mainBtn) mainBtn.style.pointerEvents = 'auto';
        UI.showToast('已同意免责声明，开始使用', 'success');
      });
    },

    /** 创建问题反馈面板 */
    createFeedbackPanel() {
      const panel = document.createElement('div');
      panel.id = 'pcas-feedback-panel';
      panel.innerHTML = `
        <div class="pcas-feedback-box">
          <div class="pcas-feedback-header">
            <span>💬</span>
            <span>问题反馈</span>
            <button class="pcas-feedback-close" id="pcas-feedback-close">✕</button>
          </div>
          <div class="pcas-feedback-body">
            <div class="pcas-feedback-welcome">
              <p>感谢您使用 PCAS Plugin！</p>
              <p>如果您在使用过程中遇到任何问题，或有改进建议，欢迎随时反馈。</p>
            </div>
            <div class="pcas-feedback-info">
              <div class="pcas-feedback-row">
                <span class="pcas-feedback-label">开发者邮箱</span>
                <a class="pcas-feedback-value pcas-feedback-link" href="mailto:331626504@qq.com">331626504@qq.com</a>
              </div>
              <div class="pcas-feedback-row">
                <span class="pcas-feedback-label">反馈内容</span>
                <textarea class="pcas-feedback-textarea" id="pcas-feedback-text" placeholder="请描述您遇到的问题或建议（选填）..." rows="4"></textarea>
              </div>
            </div>
            <div class="pcas-feedback-footer">
              <button class="pcas-feedback-btn" id="pcas-feedback-copy">📋 复制邮箱</button>
              <button class="pcas-feedback-btn pcas-feedback-btn-primary" id="pcas-feedback-send">📧 打开邮件客户端</button>
            </div>
            <div class="pcas-feedback-note">
              有问题欢迎反馈与指正 ❤️
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(panel);

      // 关闭按钮
      panel.querySelector('#pcas-feedback-close').addEventListener('click', () => {
        this.hideFeedback();
      });

      // 复制邮箱
      panel.querySelector('#pcas-feedback-copy').addEventListener('click', () => {
        navigator.clipboard.writeText('331626504@qq.com').then(() => {
          this.showToast('邮箱已复制', 'success');
        }).catch(() => {
          this.showToast('复制失败', 'error');
        });
      });

      // 打开邮件客户端
      panel.querySelector('#pcas-feedback-send').addEventListener('click', () => {
        const text = panel.querySelector('#pcas-feedback-text').value;
        const subject = encodeURIComponent('PCAS Plugin 问题反馈');
        const body = encodeURIComponent(text || '我想反馈以下问题：\n\n');
        window.open(`mailto:331626504@qq.com?subject=${subject}&body=${body}`);
      });
    },

    /** 显示问题反馈面板 */
    showFeedback() {
      const panel = document.getElementById('pcas-feedback-panel');
      if (panel) panel.classList.add('pcas-show');
    },

    /** 隐藏问题反馈面板 */
    hideFeedback() {
      const panel = document.getElementById('pcas-feedback-panel');
      if (panel) panel.classList.remove('pcas-show');
    },

    /** 创建常驻历史记录面板 */
    createHistoryPanel() {
      const panel = document.createElement('div');
      panel.id = 'pcas-history-panel';
      panel.innerHTML = `
        <div class="pcas-history-header">
          <div class="pcas-history-title">
            <span>📋</span>
            <span>历史记录</span>
            <span class="pcas-history-count" id="pcas-history-panel-count">0</span>
          </div>
          <div class="pcas-history-actions">
            <button class="pcas-history-btn" id="pcas-history-clear-btn" title="清空历史">🗑️</button>
            <button class="pcas-history-btn" id="pcas-history-close-btn" title="关闭">✕</button>
          </div>
        </div>
        <div class="pcas-history-body" id="pcas-history-list">
          <div class="pcas-history-empty">暂无历史记录</div>
        </div>
      `;
      document.body.appendChild(panel);
    },

    /** 绑定事件 */
    bindEvents() {
      // 主按钮点击
      document.getElementById('pcas-main-btn').addEventListener('click', () => {
        this.toggleMenu();
      });

      // 菜单项点击
      document.getElementById('pcas-menu').addEventListener('click', (e) => {
        const item = e.target.closest('.pcas-menu-item, .pcas-quick-btn');
        if (item) {
          const action = item.dataset.action;
          const apiType = item.dataset.api || 'normal';
          this.hideMenu();
          this.handleMenuAction(action, apiType);
        }
      });

      // 终止按钮
      document.getElementById('pcas-stop-btn').addEventListener('click', () => {
        this.stopProcessing();
      });

      // 弹窗关闭
      document.querySelector('.pcas-popup-close').addEventListener('click', () => {
        this.hideAnswerPopup();
      });
      document.getElementById('pcas-btn-cancel').addEventListener('click', () => {
        this.hideAnswerPopup();
      });

      // 填充按钮
      document.getElementById('pcas-btn-fill').addEventListener('click', () => {
        this.handleFillClick();
      });

      // 复制按钮
      document.getElementById('pcas-btn-copy').addEventListener('click', () => {
        this.handleCopyClick();
      });

      // 遮罩层点击关闭
      document.getElementById('pcas-overlay').addEventListener('click', () => {
        this.hideHistoryPanel();
        this.hideAnswerPopup();
        this.hideMenu();
      });

      // 点击外部关闭菜单
      document.addEventListener('click', (e) => {
        const panel = document.getElementById('pcas-panel');
        if (!panel.contains(e.target)) {
          this.hideMenu();
        }
      });

      // 历史面板关闭按钮
      document.getElementById('pcas-history-close-btn').addEventListener('click', () => {
        this.hideHistoryPanel();
      });

      // 历史面板清空按钮
      document.getElementById('pcas-history-clear-btn').addEventListener('click', async () => {
        await PCAS_Storage.clearHistory();
        this.hideHistoryPanel();
        this.showToast('历史记录已清空', 'info');
        this.updateHistoryCount();
      });

      // 快捷键
      document.addEventListener('keydown', (e) => {
        // Ctrl+Shift+S 触发搜题
        if (e.ctrlKey && e.shiftKey && e.key === 'S') {
          e.preventDefault();
          Core.analyzeSelected('normal');
        }
        // Alt+S 截图识别
        if (e.altKey && e.key === 's') {
          e.preventDefault();
          Core.screenshotAndAnalyze('vision');
        }
        // Escape 关闭/终止
        if (e.key === 'Escape') {
          if (Core._isProcessing) {
            this.stopProcessing();
          } else {
            this.hideHistoryPanel();
            this.hideAnswerPopup();
            this.hideMenu();
          }
        }
      });

      // 监听选中文本变化
      document.addEventListener('mouseup', () => {
        setTimeout(() => {
          const selection = window.getSelection();
          const selectedText = selection?.toString().trim();
          const quickBtns = document.querySelectorAll('.pcas-quick-btn');
          if (selectedText && selectedText.length > 2) {
            quickBtns.forEach(btn => btn.classList.add('pcas-has-selection'));
          } else {
            quickBtns.forEach(btn => btn.classList.remove('pcas-has-selection'));
          }
        }, 100);
      });
    },

    /** 切换菜单显示 */
    toggleMenu() {
      const menu = document.getElementById('pcas-menu');
      menu.classList.toggle('pcas-show');
    },

    /** 隐藏菜单 */
    hideMenu() {
      document.getElementById('pcas-menu').classList.remove('pcas-show');
    },

    /** 显示答案弹窗 */
    showAnswerPopup(answer, explanation, thinking, onFill, showFillBtn = true) {
      this._currentOnFill = onFill;

      document.getElementById('pcas-answer-text').textContent = answer;

      // 解析
      const explanationSection = document.getElementById('pcas-explanation-section');
      const explanationEl = document.getElementById('pcas-explanation');
      if (explanation) {
        explanationEl.textContent = explanation;
        explanationSection.style.display = 'block';
      } else {
        explanationSection.style.display = 'none';
      }

      // 思考过程
      const thinkingSection = document.getElementById('pcas-thinking-section');
      const thinkingEl = document.getElementById('pcas-thinking');
      if (thinking) {
        thinkingEl.textContent = thinking;
        thinkingSection.style.display = 'block';
      } else {
        thinkingSection.style.display = 'none';
      }

      // 填充按钮
      const fillBtn = document.getElementById('pcas-btn-fill');
      fillBtn.style.display = showFillBtn ? 'inline-flex' : 'none';

      // 更新标题
      const titleEl = document.getElementById('pcas-popup-title-text');
      titleEl.textContent = thinking ? '🧠 深度思考结果' : '🎯 搜题结果';

      document.getElementById('pcas-answer-popup').classList.add('pcas-show');
      document.getElementById('pcas-overlay').classList.add('pcas-show');
    },

    /** 隐藏答案弹窗 */
    hideAnswerPopup() {
      document.getElementById('pcas-answer-popup').classList.remove('pcas-show');
      document.getElementById('pcas-overlay').classList.remove('pcas-show');
      this._currentOnFill = null;
    },

    /** 显示常驻历史记录面板 */
    async showHistoryPanel() {
      const panel = document.getElementById('pcas-history-panel');
      const listEl = document.getElementById('pcas-history-list');
      const countEl = document.getElementById('pcas-history-panel-count');

      const history = await PCAS_Storage.getHistory(50);
      countEl.textContent = history.length;

      if (history.length === 0) {
        listEl.innerHTML = '<div class="pcas-history-empty">暂无历史记录</div>';
      } else {
        listEl.innerHTML = history.map((item, i) => {
          const date = new Date(item.timestamp);
          const timeStr = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
          const typeLabel = item.type === 'vision' ? '📸' : item.type === 'think' ? '🧠' : '🔍';
          const question = (item.question || '未知题目').substring(0, 60);
          const answer = item.answer || '?';
          return `
            <div class="pcas-history-item" data-answer="${this.escapeAttr(answer)}">
              <div class="pcas-history-item-header">
                <span class="pcas-history-type">${typeLabel}</span>
                <span class="pcas-history-time">${timeStr}</span>
              </div>
              <div class="pcas-history-question">${this.escapeHtml(question)}</div>
              <div class="pcas-history-answer">答案: <strong>${this.escapeHtml(answer)}</strong></div>
            </div>
          `;
        }).join('');

        // 点击历史项复制答案
        listEl.querySelectorAll('.pcas-history-item').forEach(item => {
          item.addEventListener('click', () => {
            const answer = item.dataset.answer;
            navigator.clipboard.writeText(answer).then(() => {
              this.showToast(`已复制: ${answer}`, 'success', 1500);
            }).catch(() => {
              this.showToast('复制失败', 'error');
            });
          });
        });
      }

      panel.classList.add('pcas-show');
    },

    /** 隐藏历史记录面板 */
    hideHistoryPanel() {
      document.getElementById('pcas-history-panel').classList.remove('pcas-show');
    },

    /** HTML 转义 */
    escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    },

    /** 属性值转义 */
    escapeAttr(text) {
      return text.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    },

    /** 处理填充按钮点击 */
    handleFillClick() {
      if (this._currentOnFill) {
        this._currentOnFill();
      }
      this.hideAnswerPopup();
    },

    /** 处理复制按钮点击 */
    handleCopyClick() {
      const answer = document.getElementById('pcas-answer-text').textContent;
      const explanation = document.getElementById('pcas-explanation').textContent;
      const text = explanation ? `${answer}\n\n${explanation}` : answer;

      navigator.clipboard.writeText(text).then(() => {
        this.showToast('已复制到剪贴板', 'success');
      }).catch(() => {
        // 降级方案
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        this.showToast('已复制到剪贴板', 'success');
      });
    },

    /** 处理菜单动作 */
    async handleMenuAction(action, apiType = 'normal') {
      switch (action) {
        case 'analyze-page':
          await Core.analyzeCurrentPage('normal');
          break;
        case 'analyze-selected':
          await Core.analyzeSelected('normal');
          break;
        case 'vision-selected':
          await Core.analyzeSelected('vision');
          break;
        case 'vision-screenshot':
          await Core.screenshotAndAnalyze('vision');
          break;
        case 'think-page':
          await Core.analyzeCurrentPage('think');
          break;
        case 'think-selected':
          await Core.analyzeSelected('think');
          break;
        case 'auto-fill-all':
          await Core.autoFillAll();
          break;
        case 'toggle-auto-search':
          await Core.toggleAutoSearch();
          break;
        case 'show-history':
          await Core.showHistory();
          break;
        case 'settings':
          chrome.runtime.sendMessage({ type: 'OPEN_OPTIONS' });
          break;
        case 'feedback':
          this.showFeedback();
          break;
      }
    },

    /** 停止处理 */
    stopProcessing() {
      if (abortController) {
        abortController.abort();
        abortController = null;
      }
      Core._isProcessing = false;
      this.hideStatus();
      this.setButtonState('idle');
      this.showToast('已终止处理', 'info');
    },

    /** 显示状态栏 */
    showStatus(text, showStop = true) {
      const status = document.getElementById('pcas-status');
      const statusText = status.querySelector('.pcas-status-text');
      const stopBtn = document.getElementById('pcas-stop-btn');

      statusText.textContent = text;
      stopBtn.style.display = showStop ? 'flex' : 'none';
      status.classList.remove('pcas-status-hidden');
      status.classList.add('pcas-status-visible');
    },

    /** 隐藏状态栏 */
    hideStatus() {
      const status = document.getElementById('pcas-status');
      status.classList.remove('pcas-status-visible');
      status.classList.add('pcas-status-hidden');
    },

    /** 更新状态文本 */
    updateStatus(text) {
      const statusText = document.querySelector('.pcas-status-text');
      if (statusText) {
        statusText.textContent = text;
      }
    },

    /** 显示 Toast */
    showToast(message, type = 'info', duration = 3000) {
      const toast = document.getElementById('pcas-toast');
      toast.textContent = message;
      toast.className = `pcas-show pcas-toast-${type}`;

      if (this._toastTimer) clearTimeout(this._toastTimer);
      this._toastTimer = setTimeout(() => {
        toast.classList.remove('pcas-show');
      }, duration);
    },

    /** 设置主按钮状态 */
    setButtonState(state) {
      const btn = document.getElementById('pcas-main-btn');
      btn.classList.remove('pcas-loading', 'pcas-success', 'pcas-error');

      switch (state) {
        case 'loading':
          btn.classList.add('pcas-loading');
          btn.innerHTML = '<span class="pcas-btn-icon">⏳</span>';
          break;
        case 'success':
          btn.classList.add('pcas-success');
          btn.innerHTML = '<span class="pcas-btn-icon">✅</span>';
          setTimeout(() => {
            btn.classList.remove('pcas-success');
            btn.innerHTML = '<span class="pcas-btn-icon">🔍</span>';
          }, 2000);
          break;
        case 'error':
          btn.classList.add('pcas-error');
          btn.innerHTML = '<span class="pcas-btn-icon">❌</span>';
          setTimeout(() => {
            btn.classList.remove('pcas-error');
            btn.innerHTML = '<span class="pcas-btn-icon">🔍</span>';
          }, 2000);
          break;
        default:
          btn.innerHTML = '<span class="pcas-btn-icon">🔍</span>';
      }
    },

    /** 高亮元素 */
    highlightElement(el) {
      el.classList.add('pcas-highlight');
      setTimeout(() => el.classList.remove('pcas-highlight'), 3000);
    },

    /** 更新历史计数 */
    async updateHistoryCount() {
      const data = await new Promise(resolve => {
        chrome.storage.local.get(['history'], resolve);
      });
      const count = (data.history || []).length;
      const badge = document.getElementById('pcas-history-count');
      if (badge) {
        badge.textContent = count > 99 ? '99+' : count;
        badge.style.display = count > 0 ? 'flex' : 'none';
      }
    }
  };

  // ============================================================
  // 题目提取模块
  // ============================================================
  const QuestionExtractor = {
    QUESTION_SELECTORS: [
      // 通用选择器
      '.question', '.problem', '.topic', '.timu', '.question-item',
      '.exam-item', '.test-item', '.quiz-item', '.stem',
      '[class*="question"]', '[class*="problem"]', '[class*="topic"]',
      '[class*="timu"]', '[class*="stem"]', '[data-type="question"]',
      '.el-radio-group', '.el-checkbox-group',
      'fieldset', '.form-group',
      // 超星学习通
      '.TiMu', '.Zy_TiMu', '.Zy_Timu',
      '[class*="TiMu"]', '[class*="Timu"]',
      '.question-list > div', '.exam_list > div'
    ],

    INPUT_SELECTORS: [
      'input[type="text"]', 'input[type="number"]', 'input[type="email"]',
      'textarea', '[contenteditable="true"]',
      'select', 'input[type="radio"]', 'input[type="checkbox"]'
    ],

    /** 可点击选项的选择器（现代答题平台常用的非表单元素） */
    CLICKABLE_OPTION_SELECTORS: [
      // ARIA 角色
      '[role="radio"]', '[role="checkbox"]', '[role="option"]',
      // 自定义 class
      '[class*="option-item"]', '[class*="optionItem"]',
      '[class*="answer-item"]', '[class*="answerItem"]',
      '[class*="choice-item"]', '[class*="choiceItem"]',
      '[class*="select-item"]', '[class*="selectItem"]',
      '[data-value]', '[data-option]',
      // UI 框架
      '.el-radio', '.el-checkbox',
      '.ant-radio-wrapper', '.ant-checkbox-wrapper',
      // 通用可点击元素
      'li[class*="option"]', 'li[class*="choice"]', 'li[class*="answer"]',
      'div[class*="option"]', 'div[class*="choice"]', 'div[class*="answer"]',
      // 超星学习通选项
      '.answer_p', '.answerP',
      '.Zy_TiMu ul li', '.Zy_Timu ul li',
      'ul[class*="answer"] li', 'ul[class*="option"] li',
      'p[class*="answer"]', 'p[class*="option"]',
      // 通用：题目内 li/p 元素（如果包含 A/B/C/D 前缀）
      '.TiMu li', '.TiMu p',
      '[class*="TiMu"] li', '[class*="TiMu"] p'
    ],

    extractAll() {
      const questions = [];
      const seen = new Set();

      // 优先策略：如果页面有 [role="radio"] 或 [role="checkbox"] 元素（超星等平台），直接按题号+选项分组
      const hasRadios = document.querySelectorAll('[role="radio"]').length > 0;
      const hasCheckboxes = document.querySelectorAll('[role="checkbox"]').length > 0;
      if (hasRadios || hasCheckboxes) {
        console.log(`[PCAS][LOG] 检测到 radio=${hasRadios}, checkbox=${hasCheckboxes}，使用题号分组策略`);
        const radioQuestions = this.extractByQuestionNumber();
        if (radioQuestions.length > 0) {
          return radioQuestions;
        }
      }

      for (const selector of this.QUESTION_SELECTORS) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
          if (seen.has(el)) return;
          seen.add(el);

          // 跳过导航面板：fixed/sticky 定位
          const style = window.getComputedStyle(el);
          if (style.position === 'fixed' || style.position === 'sticky') return;

          // 跳过子元素过多但文本很短的容器（导航面板特征）
          const childTexts = Array.from(el.children)
            .map(c => c.textContent?.trim() || '')
            .filter(t => t.length > 0);
          if (childTexts.length > 10 && childTexts.every(t => t.length < 5)) return;

          // 跳过章节标题（如 "一. 单选题（62分）"、"二. 多选题（38分）"）
          const rawText = el.textContent?.trim() || '';
          if (/^[一二三四五六七八九十]+[.、]\s*(单选题|多选题|判断题|填空题|简答题)/.test(rawText)) return;

          const question = this.parseQuestionElement(el);
          if (question && question.text.length > 5) {
            questions.push(question);
          }
        });
      }

      if (questions.length === 0) {
        questions.push(...this.extractByInputProximity());
      }

      // 策略3: 查找带题号的文本块（如 "1. xxx"、"2. xxx"）
      if (questions.length === 0) {
        questions.push(...this.extractByQuestionNumber());
      }

      // 去重：同一个题目元素不重复
      const uniqueQuestions = [];
      const elementSeen = new Set();
      for (const q of questions) {
        if (!elementSeen.has(q.element)) {
          elementSeen.add(q.element);
          uniqueQuestions.push(q);
        }
      }

      console.log(`[PCAS] 提取到 ${uniqueQuestions.length} 道题目`);
      uniqueQuestions.forEach((q, i) => {
        console.log(`[PCAS] 题目 ${i + 1}: ${q.text.substring(0, 50)}... (选项: ${q.options.length}, 输入: ${q.inputs.length})`);
      });

      return uniqueQuestions;
    },

    /** 判断文本是否为有效题目（排除纯标点、纯数字等无意义文本） */
    isValidQuestionText(text) {
      if (!text || text.length < 3) return false;
      // 去掉所有标点、空格、特殊符号后，看剩余内容长度
      const cleaned = text
        .replace(/[\s　]/g, '')                          // 全角/半角空格
        .replace(/[，。！？、；：""''（）【】《》…—·\-—–·]/g, '')
        .replace(/[,.!?;:'"(){}[\]<>\-\/\\@#$%^&*+=|~`]/g, '')
        .replace(/\d+/g, '')                                 // 纯数字
        .trim();
      // 去掉标点后至少要有 2 个有效字符（汉字或字母）
      return cleaned.length >= 2;
    },

    parseQuestionElement(el) {
      const text = this.extractText(el);
      if (!text || !this.isValidQuestionText(text)) return null;

      const options = this.extractOptions(el);
      const inputs = this.findRelatedInputs(el);
      const clickableOptions = this.findClickableOptions(el);

      // 将可点击选项也作为 inputs 传入，type 标记为 'clickable'
      clickableOptions.forEach(opt => {
        inputs.push({
          element: opt.element,
          type: 'clickable',
          selector: this.generateSelector(opt.element),
          optionText: opt.text
        });
      });

      return {
        text: text.trim(),
        options: options.length > 0 ? options : clickableOptions.map(o => o.text),
        inputs: inputs,
        element: el,
        selector: this.generateSelector(el)
      };
    },

    extractText(el) {
      const clone = el.cloneNode(true);
      // 移除选项、输入框、按钮等，只保留题干文本
      clone.querySelectorAll(
        '.option, .choices, label, input, select, textarea, button, ' +
        '[role="radio"], [role="checkbox"], [role="option"], ' +
        '[class*="option-item"], [class*="optionItem"], ' +
        '[class*="answer-item"], [class*="answerItem"], ' +
        '[class*="choice-item"], [class*="choiceItem"], ' +
        '.el-radio, .el-checkbox, .ant-radio-wrapper, .ant-checkbox-wrapper, ' +
        '.answer_p, .answerP, ul li, ol li'
      ).forEach(child => child.remove());
      // 移除以 A/B/C/D 开头的段落（选项文本）
      clone.querySelectorAll('p, div, span').forEach(child => {
        const text = child.textContent?.trim();
        if (text && /^[A-Da-d][.、．\s]/.test(text) && text.length < 200) {
          child.remove();
        }
      });
      return clone.textContent?.trim() || '';
    },

    extractOptions(el) {
      const options = [];

      // 1. label 元素
      el.querySelectorAll('label').forEach(label => {
        const text = label.textContent?.trim();
        if (text) options.push(text);
      });

      // 2. class 包含 option/choice 的元素
      if (options.length === 0) {
        el.querySelectorAll('.option, [class*="option"], [class*="choice"]').forEach(opt => {
          const text = opt.textContent?.trim();
          if (text) options.push(text);
        });
      }

      // 3. select 的 option
      if (options.length === 0) {
        el.querySelectorAll('select option').forEach(opt => {
          const text = opt.textContent?.trim();
          if (text && opt.value) options.push(text);
        });
      }

      // 4. 可点击选项元素（role="radio" 等）
      if (options.length === 0) {
        for (const selector of this.CLICKABLE_OPTION_SELECTORS) {
          const found = el.querySelectorAll(selector);
          if (found.length >= 2) {
            found.forEach(opt => {
              const text = opt.textContent?.trim();
              if (text) options.push(text);
            });
            break;
          }
        }
      }

      return options;
    },

    /** 查找可点击的选项元素 */
    findClickableOptions(el) {
      const results = [];
      const seen = new Set();
      const elTag = el.tagName;
      const elText = el.textContent?.trim().substring(0, 50) || '';
      console.log(`[PCAS][LOG] findClickableOptions: 在 ${elTag} "${elText}..." 中查找选项`);

      // 策略1: 通过选择器匹配
      for (const selector of this.CLICKABLE_OPTION_SELECTORS) {
        const found = el.querySelectorAll(selector);
        if (found.length >= 2) {
          console.log(`[PCAS][LOG]   选择器 "${selector}" 匹配到 ${found.length} 个元素`);
          found.forEach(opt => {
            if (seen.has(opt)) return;
            seen.add(opt);
            const text = opt.textContent?.trim();
            if (text) {
              results.push({ element: opt, text });
            }
          });
          if (results.length >= 2) break;
        }
      }

      // 策略2: 查找以 A/B/C/D 开头的兄弟元素（超星等平台常见）
      if (results.length < 2) {
        console.log(`[PCAS][LOG]   选择器策略未找到 2 个，尝试文本模式匹配...`);
        const allLi = el.querySelectorAll('li, p, div, span');
        const optionPattern = /^[A-Da-d][.、．\s]/;
        const candidateOptions = [];

        allLi.forEach(item => {
          const text = item.textContent?.trim();
          if (text && optionPattern.test(text) && text.length < 200) {
            // 确保不是嵌套太深（最多 3 层）
            let depth = 0;
            let parent = item.parentElement;
            while (parent && parent !== el) {
              depth++;
              parent = parent.parentElement;
            }
            if (depth <= 3 && !seen.has(item)) {
              seen.add(item);
              candidateOptions.push({ element: item, text });
            }
          }
        });

        // 至少要有 2 个匹配才算有效选项组
        console.log(`[PCAS][LOG]   文本模式匹配到 ${candidateOptions.length} 个候选`);
        if (candidateOptions.length >= 2) {
          results.push(...candidateOptions);
        }
      }

      console.log(`[PCAS][LOG]   最终找到 ${results.length} 个可点击选项`);
      results.forEach((r, i) => console.log(`[PCAS][LOG]     [${i}] "${r.text.substring(0, 40)}"`));
      return results;
    },

    findRelatedInputs(el) {
      const inputs = [];
      el.querySelectorAll(this.INPUT_SELECTORS).forEach(input => {
        inputs.push({
          element: input,
          type: input.type || input.tagName.toLowerCase(),
          selector: this.generateSelector(input)
        });
      });
      return inputs;
    },

    extractByInputProximity() {
      const questions = [];
      const inputs = document.querySelectorAll(this.INPUT_SELECTORS);

      inputs.forEach(input => {
        const container = this.findNearestTextContainer(input);
        if (container) {
          const text = this.extractText(container);
          if (text && text.length > 5 && text.length < 2000 && this.isValidQuestionText(text)) {
            questions.push({
              text: text.trim(),
              options: this.extractOptions(container),
              inputs: [{
                element: input,
                type: input.type || input.tagName.toLowerCase(),
                selector: this.generateSelector(input)
              }],
              element: container,
              selector: this.generateSelector(container)
            });
          }
        }
      });

      console.log(`[PCAS][LOG] extractByInputProximity 提取到 ${questions.length} 道题目`);
      return questions;
    },

    /** 通过题号模式提取题目（超星等平台：1. xxx 或 1、xxx） */
    extractByQuestionNumber() {
      const questions = [];
      const seen = new Set();
      const numberPattern = /^\s*(\d+[.、．)\）])\s*/;

      // ① 收集所有可交互元素
      const allRadios = Array.from(document.querySelectorAll('[role="radio"]'));
      const allCheckboxes = Array.from(document.querySelectorAll('[role="checkbox"]'));
      const allTextInputs = Array.from(document.querySelectorAll('input[type="text"], input:not([type]), textarea, [contenteditable="true"]')).filter(el => {
        // 过滤掉搜索框等非答题输入框
        const rect = el.getBoundingClientRect();
        if (rect.width < 50 || rect.height < 10) return false;
        const ph = (el.placeholder || '').toLowerCase();
        if (ph.includes('search') || ph.includes('搜索')) return false;
        // 过滤掉 PCAS 自己的元素
        if (el.closest('#pcas-panel') || el.closest('#pcas-history-panel')) return false;
        return true;
      });
      console.log(`[PCAS][LOG] extractByQuestionNumber: radio=${allRadios.length}, checkbox=${allCheckboxes.length}, textInput=${allTextInputs.length}`);

      // ② 辅助：从元素向前找题干文本
      const findQuestionTextForward = (el) => {
        const elTag = el.tagName;
        const elText = el.value || el.textContent?.trim().substring(0, 30) || '';
        console.log(`[PCAS][LOG] findQuestionText: 从 ${elTag} "${elText}" 向前查找题干`);
        let current = el;
        for (let depth = 0; depth < 15 && current; depth++) {
          current = current.parentElement;
          if (!current) break;
          let prev = current.previousElementSibling;
          while (prev) {
            const text = prev.textContent?.trim() || '';
            const m = text.match(/^\s*(\d+[.、．)\）]\s*.+)/);
            if (m && m[1].length > 5) {
              console.log(`[PCAS][LOG] findQuestionText: 找到(精确) "${m[1].trim().substring(0, 50)}"`);
              return { text: m[1].trim(), element: prev };
            }
            const m2 = text.match(/^\s*(\d+[.、])\s*(.{4,})/);
            if (m2) {
              console.log(`[PCAS][LOG] findQuestionText: 找到(宽松) "${text.trim().substring(0, 50)}"`);
              return { text: text.trim(), element: prev };
            }
            prev = prev.previousElementSibling;
          }
          // 也检查自身
          const selfText = current.textContent?.trim() || '';
          const m3 = selfText.match(/^\s*(\d+[.、．)\）]\s*.+)/);
          if (m3 && m3[1].length > 5) {
            const optCount = current.querySelectorAll('[role="radio"], [role="checkbox"], input[type="text"]').length;
            if (optCount <= 7) return { text: m3[1].trim(), element: current };
          }
        }
        // 策略 B: 找前面的兄弟
        const parent = el.closest('[class*="option"], [class*="answer"], [class*="TiMu"]') || el.parentElement;
        if (parent) {
          const prev = parent.previousElementSibling;
          if (prev) {
            const text = prev.textContent?.trim() || '';
            if (text.length > 5 && text.length < 500) {
              console.log(`[PCAS][LOG] findQuestionText: 找到(兄弟) "${text.substring(0, 50)}"`);
              return { text, element: prev };
            }
          }
        }
        console.log(`[PCAS][LOG] findQuestionText: 未找到题干!`);
        return null;
      };

      // ③ 处理 radio/checkbox 选项题（单选、多选、判断）
      const allOptions = [...allRadios, ...allCheckboxes];
      allOptions.sort((a, b) => {
        const pos = a.compareDocumentPosition(b);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      const visibleOptions = allOptions.filter(r => {
        const rect = r.getBoundingClientRect();
        return rect.width > 0 || rect.height > 0;
      });

      // 按 role 分组
      const roleGroups = [];
      let curGroup = [];
      let curRole = null;
      for (const opt of visibleOptions) {
        const role = opt.getAttribute('role');
        if (role !== curRole && curGroup.length > 0) {
          roleGroups.push({ role: curRole, items: [...curGroup] });
          curGroup = [];
        }
        curGroup.push(opt);
        curRole = role;
      }
      if (curGroup.length > 0) roleGroups.push({ role: curRole, items: [...curGroup] });

      // 智能拆分：检测选项文本是否重复来判断题目边界
      const optionGroups = [];
      for (const rg of roleGroups) {
        let i = 0;
        while (i < rg.items.length) {
          // 检查当前选项的文本
          const currentText = rg.items[i].textContent?.trim().replace(/\s+/g, '') || '';
          const currentLetter = currentText.match(/^[(\[]?([A-Za-z])/)?.[1] || '';

          // 找到当前题目的结束位置
          let end = i + 1;
          while (end < rg.items.length) {
            const nextText = rg.items[end].textContent?.trim().replace(/\s+/g, '') || '';
            const nextLetter = nextText.match(/^[(\[]?([A-Za-z])/)?.[1] || '';

            // 如果下一个选项的字母和当前题目的第一个选项字母相同，说明是新题目
            if (nextLetter && nextLetter === currentLetter && end > i + 1) {
              break;
            }
            end++;
          }

          const chunk = rg.items.slice(i, end);
          if (chunk.length >= 2) {
            optionGroups.push({ role: rg.role, items: chunk });
          }
          i = end;
        }
      }

      console.log(`[PCAS][LOG]   选项题分组: ${optionGroups.length} 组`);
      for (let g = 0; g < optionGroups.length; g++) {
        const qg = optionGroups[g];
        const group = qg.items;
        const isMulti = qg.role === 'checkbox';
        const first = group[0];

        const qt = findQuestionTextForward(first);
        if (!qt) {
          console.log(`[PCAS][LOG]   选项组${g + 1}: 未找到题干，跳过`);
          continue;
        }

        // 过滤章节标题
        if (/^[一二三四五六七八九十]+[.、]/.test(qt.text)) continue;
        // 判断题：2 个选项且文本含"判断"或选项含"对/错"
        const optTexts = group.map(r => r.textContent?.trim() || '');
        const isJudge = group.length === 2 && (/判断/.test(qt.text) || (optTexts[0].includes('对') && optTexts[1].includes('错')));
        console.log(`[PCAS][LOG]   选项组${g + 1}: "${qt.text.substring(0, 50)}" options=${JSON.stringify(optTexts)} isJudge=${isJudge} isMulti=${isMulti}`);

        const shortText = qt.text.substring(0, 80);
        if (seen.has(shortText)) continue;
        seen.add(shortText);

        questions.push({
          text: qt.text,
          options: group.map(r => r.textContent?.trim() || ''),
          inputs: group.map(r => ({
            element: r,
            type: 'clickable',
            selector: this.generateSelector(r),
            optionText: r.textContent?.trim() || ''
          })),
          element: qt.element,
          selector: this.generateSelector(qt.element),
          isMultiSelect: isMulti,
          questionType: isJudge ? 'judge' : (isMulti ? 'multi' : 'single')
        });

        const typeLabel = isJudge ? '判断' : (isMulti ? '多选' : '单选');
        console.log(`[PCAS][LOG]   题${g + 1}(${typeLabel}): "${qt.text.substring(0, 50)}" → ${group.length} 个选项`);
      }

      // ④ 处理填空题（文本输入框 + UEditor iframe）
      const visibleInputs = allTextInputs.filter(el => {
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      });

      // 也检测 UEditor iframe 中的 contenteditable body
      const allIframes = Array.from(document.querySelectorAll('iframe'));
      const ueditorBodies = [];
      allIframes.forEach(iframe => {
        try {
          const doc = iframe.contentDocument;
          if (doc && doc.body && doc.body.contentEditable === 'true') {
            const rect = iframe.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
              ueditorBodies.push({ iframe, body: doc.body, rect });
            }
          }
        } catch (e) { /* 跨域跳过 */ }
      });

      console.log(`[PCAS][LOG]   填空题: textInput=${visibleInputs.length}, ueditor=${ueditorBodies.length}`);

      // 策略A: 传统 input/textarea 填空
      for (const input of visibleInputs) {
        const qt = findQuestionTextForward(input);
        if (!qt) continue;
        if (/^[一二三四五六七八九十]+[.、]/.test(qt.text)) continue;
        if (!/填空|___|____|__/.test(qt.text)) continue;

        const shortText = qt.text.substring(0, 80);
        if (seen.has(shortText)) continue;
        seen.add(shortText);

        questions.push({
          text: qt.text,
          options: [],
          inputs: [{ element: input, type: 'text', selector: this.generateSelector(input), optionText: '' }],
          element: qt.element,
          selector: this.generateSelector(qt.element),
          isMultiSelect: false,
          questionType: 'fill'
        });
        console.log(`[PCAS][LOG]   填空(传统): "${qt.text.substring(0, 50)}"`);
      }

      // 策略B: UEditor iframe 填空（超星填空题）
      // 找所有 "第X空" 标签，每个标签对应一个 UEditor
      const tiankongLabels = Array.from(document.querySelectorAll('span.tiankong, .tiankong'));
      console.log(`[PCAS][LOG]   tiankong 标签: ${tiankongLabels.length} 个`);

      if (tiankongLabels.length > 0) {
        // 按题目分组：找到每个填空题的所有空
        const fillGroups = new Map(); // key=题目文本, value={text, inputs:[]}

        for (const label of tiankongLabels) {
          const labelParent = label.closest('.Answer') || label.parentElement;
          if (!labelParent) continue;

          // 找到这个空对应的 UEditor iframe
          const editorContainer = labelParent.querySelector('.edui-editor, .textDIV, .divText');
          let targetBody = null;

          if (editorContainer) {
            const iframe = editorContainer.querySelector('iframe');
            if (iframe) {
              try {
                const doc = iframe.contentDocument;
                if (doc && doc.body) {
                  targetBody = doc.body;
                }
              } catch (e) {}
            }
          }

          // 如果找不到 iframe，尝试在父容器中找
          if (!targetBody) {
            const nearbyIframe = labelParent.querySelector('iframe');
            if (nearbyIframe) {
              try {
                const doc = nearbyIframe.contentDocument;
                if (doc && doc.body) targetBody = doc.body;
              } catch (e) {}
            }
          }

          // 向上找更多层级
          if (!targetBody) {
            let up = labelParent;
            for (let d = 0; d < 5 && up; d++) {
              const iframe = up.querySelector('iframe');
              if (iframe) {
                try {
                  const doc = iframe.contentDocument;
                  if (doc && doc.body && doc.body.contentEditable === 'true') {
                    targetBody = doc.body;
                    break;
                  }
                } catch (e) {}
              }
              up = up.parentElement;
            }
          }

          if (!targetBody) {
            console.log(`[PCAS][LOG]     "${label.textContent}" 未找到 UEditor iframe`);
            continue;
          }

          // 找到这道题的题干文本
          const questionContainer = labelParent.closest('.TiMu, .Zy_TiMu, [class*="question"], [class*="timu"]') || labelParent.parentElement;
          let questionText = '';
          if (questionContainer) {
            // 找题干：在 "第X空" 之前的文本
            const allText = questionContainer.textContent || '';
            const match = allText.match(/^\s*(\d+[.、．)\）]\s*.+?)(?:\d+[.、]|\s*$)/);
            if (match) questionText = match[1].trim();
          }

          if (!questionText) {
            // 用 label 的父容器向上找
            let up = labelParent;
            for (let d = 0; d < 10 && up; d++) {
              const selfText = up.textContent?.trim() || '';
              const m = selfText.match(/^\s*(\d+[.、．)\）]\s*.+)/);
              if (m && m[1].length > 5 && /填空/.test(m[1])) {
                questionText = m[1].trim();
                break;
              }
              up = up.parentElement;
            }
          }

          const groupKey = questionText || label.textContent;
          if (!fillGroups.has(groupKey)) {
            fillGroups.set(groupKey, { text: questionText, inputs: [] });
          }
          fillGroups.get(groupKey).inputs.push({
            element: targetBody,
            type: 'ueditor',
            selector: '',
            optionText: ''
          });

          console.log(`[PCAS][LOG]     "${label.textContent}" → UEditor body found`);
        }

        // 构建填空题
        for (const [key, group] of fillGroups) {
          if (group.inputs.length === 0) continue;
          if (!group.text) continue;

          const shortText = group.text.substring(0, 80);
          if (seen.has(shortText)) continue;
          seen.add(shortText);

          questions.push({
            text: group.text,
            options: [],
            inputs: group.inputs,
            element: null,
            selector: '',
            isMultiSelect: false,
            questionType: 'fill'
          });

          console.log(`[PCAS][LOG]   填空(UEditor): "${group.text.substring(0, 50)}" → ${group.inputs.length} 个空`);
        }
      }

      // 策略C: 编程题/简答题（没有"第1空"标签的独立 UEditor）
      // 找到所有已经被 "第1空" 标签关联过的 UEditor body
      const usedBodies = new Set();
      for (const label of tiankongLabels) {
        const labelParent = label.closest('.Answer') || label.parentElement;
        if (!labelParent) continue;
        const editorContainer = labelParent.querySelector('.edui-editor, .textDIV, .divText');
        if (editorContainer) {
          const iframe = editorContainer.querySelector('iframe');
          if (iframe) {
            try {
              const doc = iframe.contentDocument;
              if (doc && doc.body) usedBodies.add(doc.body);
            } catch (e) {}
          }
        }
      }

      // 找所有可见的 UEditor body，排除已关联的
      const allUebodies = [];
      allIframes.forEach(iframe => {
        try {
          const doc = iframe.contentDocument;
          if (doc && doc.body && doc.body.contentEditable === 'true' && !usedBodies.has(doc.body)) {
            const rect = iframe.getBoundingClientRect();
            if (rect.width > 50 && rect.height > 50) {
              allUebodies.push({ iframe, body: doc.body, rect });
            }
          }
        } catch (e) {}
      });

      console.log(`[PCAS][LOG]   未关联的 UEditor: ${allUebodies.length} 个`);

      for (const ue of allUebodies) {
        // 向上找题干文本
        let questionText = '';
        let current = ue.iframe;
        for (let depth = 0; depth < 15 && current; depth++) {
          current = current.parentElement;
          if (!current) break;
          let prev = current.previousElementSibling;
          while (prev) {
            const text = prev.textContent?.trim() || '';
            const m = text.match(/^\s*(\d+[.、．)\）]\s*.+)/);
            if (m && m[1].length > 5) {
              questionText = m[1].trim();
              break;
            }
            const m2 = text.match(/^\s*(\d+[.、])\s*(.{4,})/);
            if (m2) {
              questionText = text.trim();
              break;
            }
            prev = prev.previousElementSibling;
          }
          if (questionText) break;
        }

        if (!questionText) continue;
        if (/^[一二三四五六七八九十]+[.、]/.test(questionText)) continue;

        const shortText = questionText.substring(0, 80);
        if (seen.has(shortText)) continue;
        seen.add(shortText);

        // 判断题目类型
        const qType = /编程|代码|简答|论述|问答/.test(questionText) ? 'essay' : 'fill';

        questions.push({
          text: questionText,
          options: [],
          inputs: [{
            element: ue.body,
            type: 'ueditor',
            selector: '',
            optionText: ''
          }],
          element: null,
          selector: '',
          isMultiSelect: false,
          questionType: qType
        });

        console.log(`[PCAS][LOG]   ${qType === 'essay' ? '编程/简答' : '填空'}(独立UEditor): "${questionText.substring(0, 50)}"`);
      }

      // 按 DOM 顺序排序（题号顺序）
      questions.sort((a, b) => {
        const numA = parseInt(a.text.match(/\d+/)?.[0] || '0');
        const numB = parseInt(b.text.match(/\d+/)?.[0] || '0');
        return numA - numB;
      });

      console.log(`[PCAS][LOG] extractByQuestionNumber 最终提取到 ${questions.length} 道题目`);
      questions.forEach((q, i) => {
        console.log(`[PCAS][LOG]   #${i + 1} [${q.questionType}] "${q.text.substring(0, 50)}" inputs=${q.inputs.length}`);
      });
      return questions;
    },

    findNearestTextContainer(el) {
      let current = el.parentElement;
      const maxDepth = 5;
      let depth = 0;

      while (current && depth < maxDepth) {
        const text = current.textContent?.trim() || '';
        if (text.length > 10 && text.length < 5000) {
          return current;
        }
        current = current.parentElement;
        depth++;
      }
      return null;
    },

    generateSelector(el) {
      if (el.id) return `#${el.id}`;
      if (el.className && typeof el.className === 'string') {
        const classes = el.className.trim().split(/\s+/).filter(c => !c.startsWith('pcas-'));
        if (classes.length) {
          return `${el.tagName.toLowerCase()}.${classes.join('.')}`;
        }
      }
      const parent = el.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children);
        const index = siblings.indexOf(el) + 1;
        return `${this.generateSelector(parent)} > ${el.tagName.toLowerCase()}:nth-child(${index})`;
      }
      return el.tagName.toLowerCase();
    }
  };

  // ============================================================
  // 答案填充模块
  // ============================================================
  const AnswerFiller = {
    async fill(inputEl, answer, delay = 300) {
      if (!inputEl || !answer) {
        console.warn('[PCAS][LOG] fill: 参数无效', { inputEl: !!inputEl, answer: answer?.substring(0, 20) });
        return false;
      }

      const tag = inputEl.tagName?.toLowerCase();
      const type = inputEl.type?.toLowerCase();
      const isContentEditable = inputEl.contentEditable === 'true';
      console.log(`[PCAS][LOG] fill: tag=${tag} type=${type} contentEditable=${isContentEditable} answer="${answer.substring(0, 30)}"`);

      try {
        if (tag === 'select') {
          await this.fillSelect(inputEl, answer, delay);
        } else if (type === 'radio' || type === 'checkbox') {
          const filled = await this.fillRadioCheckbox(inputEl, answer, delay);
          if (!filled) {
            console.warn('[PCAS] 选择题匹配失败:', answer);
          }
        } else if (type === 'clickable') {
          // 可点击选项元素（现代答题平台）
          await this.simulateClick(inputEl);
        } else if (isContentEditable || tag === 'body' || inputEl.isContentEditable) {
          // contenteditable 元素（包括 UEditor iframe 内的 body）
          await this.fillContentEditable(inputEl, answer, delay);
        } else if (tag === 'input' || tag === 'textarea') {
          await this.fillInput(inputEl, answer, delay);
        } else {
          await this.fillGeneric(inputEl, answer, delay);
        }

        inputEl.classList.add('pcas-filling');
        setTimeout(() => inputEl.classList.remove('pcas-filling'), 500);
        return true;
      } catch (error) {
        console.error('[PCAS] 填充失败:', error);
        return false;
      }
    },

    /**
     * 智能填充选择题（根据答案自动找到对应的选择题输入框）
     * @param {Array} inputs - 题目关联的所有输入元素
     * @param {string} answer - 答案文本
     * @param {number} delay - 填充延迟
     */
    async fillChoiceQuestion(inputs, answer, delay = 300, isMultiSelect = false) {
      if (!inputs || inputs.length === 0 || !answer) {
        console.warn('[PCAS][LOG] fillChoiceQuestion: inputs 为空或 answer 为空', { inputs: inputs?.length, answer });
        return false;
      }

      // 提取所有答案字母（支持 "AB", "A,B,C", "A B C" 等格式）
      const letters = this.extractAnswerLetters(answer);
      console.log(`[PCAS][LOG] fillChoiceQuestion: answer="${answer}", letters=[${letters}], multi=${isMultiSelect}, inputs=${inputs.length}个`);

      // 1. 优先处理可点击选项（现代答题平台的 div/li/span 等）
      const clickableInputs = inputs.filter(inp => inp.type === 'clickable' && inp.element);
      console.log(`[PCAS][LOG]   可点击选项: ${clickableInputs.length} 个`);
      if (clickableInputs.length > 0) {
        const r = await this.fillClickableOptions(clickableInputs, answer, letters, delay, isMultiSelect);
        console.log(`[PCAS][LOG]   fillClickableOptions 结果: ${r}`);
        return r;
      }

      // 2. radio/checkbox
      const choiceInputs = inputs.filter(inp =>
        inp.element && (inp.element.type === 'radio' || inp.element.type === 'checkbox')
      );
      console.log(`[PCAS][LOG]   radio/checkbox: ${choiceInputs.length} 个`);
      if (choiceInputs.length > 0) {
        return await this.fillRadioCheckbox(choiceInputs[0].element, answer, delay);
      }

      // 3. select
      const selectInputs = inputs.filter(inp => inp.element && inp.element.tagName === 'SELECT');
      console.log(`[PCAS][LOG]   select: ${selectInputs.length} 个`);
      if (selectInputs.length > 0) {
        return await this.fillSelect(selectInputs[0].element, answer, delay);
      }

      // 4. 文本输入
      const textInputs = inputs.filter(inp =>
        inp.element && (inp.element.tagName === 'INPUT' || inp.element.tagName === 'TEXTAREA')
      );
      if (textInputs.length > 0) {
        return await this.fill(textInputs[0].element, answer, delay);
      }

      return false;
    },

    async fillInput(el, answer, delay) {
      console.log(`[PCAS][LOG] fillInput: 开始, 当前值="${el.value}"`);
      el.focus();
      await this.sleep(delay / 2);

      // 方法1: 使用原生 setter（兼容 React/Vue）
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value') ||
                         Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');

      if (descriptor && descriptor.set) {
        descriptor.set.call(el, answer);
      } else {
        // 方法2: 直接设置 value
        el.value = answer;
      }

      // 触发多种事件确保兼容性
      this.triggerEvents(el);
      console.log(`[PCAS][LOG] fillInput: 完成, 新值="${el.value}"`);
    },

    async fillGeneric(el, answer, delay) {
      el.focus();
      await this.sleep(delay / 2);

      // 尝试直接设置 value
      if ('value' in el) {
        el.value = answer;
      }
      // 尝试设置 textContent
      else if ('textContent' in el) {
        el.textContent = answer;
      }
      // 尝试设置 innerHTML
      else if ('innerHTML' in el) {
        el.innerHTML = answer;
      }

      this.triggerEvents(el);
    },

    async fillContentEditable(el, answer, delay) {
      console.log(`[PCAS][LOG] fillContentEditable: tag=${el.tagName} id=${el.id}`);

      // 获取正确的 document 上下文（iframe 内的 body 需要用 iframe 的 document）
      const doc = el.ownerDocument || el.document || document;

      el.focus();
      await this.sleep(delay / 2);

      // 清空现有内容
      el.innerHTML = '';

      // 方法1: 使用 execCommand（在正确的 document 上下文中）
      try {
        doc.execCommand('insertText', false, answer);
      } catch (e) {
        // 方法2: 直接设置 innerHTML
        el.innerHTML = answer;
      }

      // 方法3: 如果是 UEditor，尝试通过 API 更新
      try {
        if (window.UE && window.UE.instants) {
          for (const key in window.UE.instants) {
            const ue = window.UE.instants[key];
            if (ue && ue.body === el) {
              ue.setContent(answer);
              console.log(`[PCAS][LOG]   UEditor API 更新: ${key}`);
              break;
            }
          }
        }
      } catch (e) {}

      this.triggerEvents(el);
    },

    async fillSelect(el, answer, delay) {
      el.focus();
      await this.sleep(delay / 2);

      const options = Array.from(el.options);
      const letterMatch = answer.match(/^[A-Za-z]/);
      const answerLetter = letterMatch ? letterMatch[0].toUpperCase() : null;

      // 策略1: 精确匹配
      let match = options.find(opt => {
        const text = opt.textContent.trim();
        return text === answer || opt.value === answer;
      });

      // 策略2: 包含匹配
      if (!match) {
        match = options.find(opt => {
          const text = opt.textContent.trim();
          return text.includes(answer) || answer.includes(text);
        });
      }

      // 策略3: 选项字母匹配（A/B/C/D 对应第 N 个选项）
      if (!match && answerLetter) {
        const index = answerLetter.charCodeAt(0) - 65; // A=0, B=1, ...
        // 跳过第一个如果是 placeholder（如 "请选择"）
        const startIndex = options.length > 0 && !options[0].value ? 1 : 0;
        const targetIndex = startIndex + index;
        if (targetIndex >= 0 && targetIndex < options.length) {
          match = options[targetIndex];
        }
      }

      // 策略4: 选项文本以字母开头匹配
      if (!match && answerLetter) {
        match = options.find(opt => {
          const text = opt.textContent.trim();
          const m = text.match(/^[(\[]?([A-Za-z])[).、\s]/);
          return m && m[1].toUpperCase() === answerLetter;
        });
      }

      if (match) {
        el.value = match.value;
        this.triggerEvents(el);
      }
    },

    async fillRadioCheckbox(el, answer, delay) {
      const name = el.name;
      const form = el.form || document;
      const group = form.querySelectorAll(`input[name="${name}"]`);

      // 提取答案中的选项字母（如 "A", "B.", "A、", "(A)" 等）
      const letterMatch = answer.match(/^[A-Za-z]/);
      const answerLetter = letterMatch ? letterMatch[0].toUpperCase() : null;

      // 尝试多种匹配策略
      for (const radio of group) {
        const label = radio.closest('label') || form.querySelector(`label[for="${radio.id}"]`);
        const labelText = label?.textContent?.trim() || '';
        const radioValue = radio.value?.trim();

        // 策略1: 精确匹配选项字母
        if (answerLetter) {
          // 匹配 value 为 A/B/C/D 的情况
          if (radioValue && radioValue.toUpperCase() === answerLetter) {
            await this.selectRadio(radio, label, delay);
            return true;
          }
          // 匹配 label 以 A./A、/A)/（A）等开头的情况
          const labelLetter = labelText.match(/^[(\[]?([A-Za-z])[).、\s]/);
          if (labelLetter && labelLetter[1].toUpperCase() === answerLetter) {
            await this.selectRadio(radio, label, delay);
            return true;
          }
        }

        // 策略2: 文本包含匹配
        if (labelText.includes(answer) || answer.includes(labelText) ||
            radioValue === answer || answer.includes(radioValue)) {
          await this.selectRadio(radio, label, delay);
          return true;
        }
      }

      // 策略3: 按索引匹配（A=0, B=1, C=2, D=3）
      if (answerLetter && group.length > 0) {
        const index = answerLetter.charCodeAt(0) - 65; // A=0, B=1, ...
        if (index >= 0 && index < group.length) {
          const radio = group[index];
          const label = radio.closest('label') || form.querySelector(`label[for="${radio.id}"]`);
          await this.selectRadio(radio, label, delay);
          return true;
        }
      }

      return false;
    },

    /** 选中 radio/checkbox 并触发事件 */
    async selectRadio(radio, label, delay) {
      await this.sleep(delay);
      radio.checked = true;
      radio.dispatchEvent(new Event('change', { bubbles: true }));
      radio.dispatchEvent(new Event('click', { bubbles: true }));
      if (label) label.click();
    },

    /**
     * 从答案文本中提取所有选项字母
     * 支持格式: "A", "AB", "A,B,C", "A B C", "A、B、C", "D|因为xxx" 等
     * @param {string} answer - 答案文本
     * @returns {string[]} 字母数组，如 ["A"], ["A","B","C"]
     */
    extractAnswerLetters(answer) {
      if (!answer) return [];
      // 先取 | 分隔前的部分（去掉解释）
      const main = answer.split('|')[0].trim();
      // 提取所有连续或分隔的字母
      const letters = [];
      // 匹配 A/B/C/D（连续如 "AB" 或分隔如 "A,B" "A B" "A、B"）
      const matches = main.match(/[A-Da-d]/g);
      if (matches) {
        const seen = new Set();
        for (const m of matches) {
          const upper = m.toUpperCase();
          if (!seen.has(upper)) {
            seen.add(upper);
            letters.push(upper);
          }
        }
      }
      return letters;
    },

    /**
     * 填充可点击选项（现代答题平台的 div/li/span 等非表单元素）
     * @param {Array} clickableInputs - type='clickable' 的输入项数组
     * @param {string} answer - 完整答案文本
     * @param {string[]} letters - 答案字母数组
     * @param {number} delay - 延迟
     * @param {boolean} isMultiSelect - 是否多选
     */
    async fillClickableOptions(clickableInputs, answer, letters, delay = 300, isMultiSelect = false) {
      const options = clickableInputs.map(inp => ({
        element: inp.element,
        text: inp.optionText || inp.element.textContent?.trim() || ''
      }));

      console.log(`[PCAS][LOG] fillClickableOptions: answer="${answer}", letters=[${letters}], multi=${isMultiSelect}`);
      console.log(`[PCAS][LOG]   可点击选项列表:`);
      options.forEach((opt, i) => {
        const el = opt.element;
        const rect = el.getBoundingClientRect();
        console.log(`[PCAS][LOG]     [${i}] tag=${el.tagName} class="${el.className}" text="${opt.text.substring(0, 50)}" visible=${rect.width > 0 && rect.height > 0} rect=${Math.round(rect.width)}x${Math.round(rect.height)} at (${Math.round(rect.left)},${Math.round(rect.top)})`);
      });

      // 辅助函数：按单个字母查找匹配的选项索引
      const findOptionByLetter = (letter) => {
        // 策略1: 按字母索引匹配（A=0, B=1, C=2, D=3）
        const index = letter.charCodeAt(0) - 65;
        if (index >= 0 && index < options.length) {
          return index;
        }
        // 策略2: 匹配选项文本以答案字母开头（如 "A. xxx"、"A、xxx"）
        const textIdx = options.findIndex(opt => {
          const m = opt.text.match(/^[(\[]?([A-Za-z])[).、\s]/);
          return m && m[1].toUpperCase() === letter;
        });
        if (textIdx >= 0) return textIdx;
        // 策略3: 匹配 data-value 或 data-option 属性
        const dataIdx = options.findIndex(opt => {
          const dv = opt.element.getAttribute('data-value') || opt.element.getAttribute('data-option') || '';
          return dv.toUpperCase() === letter;
        });
        if (dataIdx >= 0) return dataIdx;
        return -1;
      };

      // 多选题：逐个字母点击
      if (isMultiSelect && letters.length > 1) {
        console.log(`[PCAS][LOG]   多选模式，需要点击 ${letters.length} 个选项: [${letters}]`);
        let clickedCount = 0;
        for (const letter of letters) {
          const idx = findOptionByLetter(letter);
          if (idx >= 0) {
            console.log(`[PCAS][LOG]   → 点击选项 ${letter}: "${options[idx].text.substring(0, 30)}"`);
            await this.sleep(delay);
            await this.simulateClick(options[idx].element);
            clickedCount++;
          } else {
            console.warn(`[PCAS][LOG]   → 选项 ${letter} 未找到匹配`);
          }
        }
        return clickedCount > 0;
      }

      // 单选题：只点击第一个字母
      const letter = letters[0];
      if (letter) {
        const idx = findOptionByLetter(letter);
        if (idx >= 0) {
          console.log(`[PCAS][LOG]   → 点击选项 ${letter}: "${options[idx].text.substring(0, 30)}"`);
          await this.sleep(delay);
          await this.simulateClick(options[idx].element);
          return true;
        }
      }

      // 策略4: 匹配选项文本包含答案
      const matched = options.find(opt => {
        const t = opt.text;
        return t === answer || t.includes(answer) || answer.includes(t);
      });
      console.log(`[PCAS][LOG]   策略4(文本包含): ${matched ? '匹配到 "' + matched.text.substring(0, 30) + '"' : '未匹配'}`);
      if (matched) {
        await this.sleep(delay);
        await this.simulateClick(matched.element);
        return true;
      }

      console.warn(`[PCAS][LOG]   所有策略均未匹配! answer="${answer}"`);
      return false;
    },

    /**
     * 模拟完整的鼠标点击序列（mousedown → mouseup → click）
     * 确保各种前端框架都能正确响应
     */
    async simulateClick(el) {
      if (!el) {
        console.error('[PCAS][LOG] simulateClick: el 为 null!');
        return;
      }

      const text = el.textContent?.trim().substring(0, 40) || '';
      console.log(`[PCAS][LOG] simulateClick: tag=${el.tagName}, text="${text}"`);

      // 滚动到元素可视区域
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await this.sleep(100);

      const rect = el.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;

      console.log(`[PCAS][LOG]   位置: (${Math.round(x)}, ${Math.round(y)}), 尺寸: ${Math.round(rect.width)}x${Math.round(rect.height)}, 可见: ${rect.width > 0 && rect.height > 0}`);

      const commonProps = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: x,
        screenY: y
      };

      // 完整的鼠标事件序列
      el.dispatchEvent(new PointerEvent('pointerdown', { ...commonProps, pointerId: 1 }));
      el.dispatchEvent(new MouseEvent('mousedown', commonProps));

      await this.sleep(50);

      el.dispatchEvent(new PointerEvent('pointerup', { ...commonProps, pointerId: 1 }));
      el.dispatchEvent(new MouseEvent('mouseup', commonProps));
      el.dispatchEvent(new MouseEvent('click', commonProps));

      // 高亮效果
      el.classList.add('pcas-filling');
      setTimeout(() => el.classList.remove('pcas-filling'), 500);

      console.log(`[PCAS][LOG]   ✓ 点击事件已派发`);
    },

    triggerEvents(el) {
      // 触发多种事件确保框架能检测到变化
      const events = [
        new Event('input', { bubbles: true, cancelable: true }),
        new Event('change', { bubbles: true, cancelable: true }),
        new Event('blur', { bubbles: true }),
        new KeyboardEvent('keydown', { bubbles: true, key: 'a' }),
        new KeyboardEvent('keyup', { bubbles: true, key: 'a' })
      ];

      events.forEach(event => {
        try {
          el.dispatchEvent(event);
        } catch (e) {
          // 忽略事件派发错误
        }
      });

      // 针对 React 的特殊处理
      const reactKey = Object.keys(el).find(key => key.startsWith('__reactFiber$') || key.startsWith('__reactInternalInstance$'));
      if (reactKey) {
        // 触发 React 的 onChange
        const tracker = el._valueTracker;
        if (tracker) {
          tracker.setValue('');
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
    },

    sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
  };

  // ============================================================
  // 核心逻辑模块
  // ============================================================
  const Core = {
    _isProcessing: false,
    _currentQuestions: [],
    _autoSearchEnabled: false,
    _autoSearchTimer: null,
    _autoSearchDebounce: null,
    /** 已回答题目的哈希集合，防止重复搜索 */
    _answeredSet: new Set(),

    /** 生成题目文本的简短哈希（用于去重） */
    _hashQuestion(text) {
      const clean = text.replace(/\s+/g, '').substring(0, 200);
      let hash = 0;
      for (let i = 0; i < clean.length; i++) {
        hash = ((hash << 5) - hash) + clean.charCodeAt(i);
        hash = hash & hash;
      }
      return Math.abs(hash).toString(36);
    },

    async analyzeCurrentPage(apiType = 'normal') {
      if (this._isProcessing) {
        UI.showToast('正在处理中，请稍候...', 'info');
        return;
      }

      this._isProcessing = true;
      abortController = new AbortController();

      const apiLabel = apiType === 'vision' ? '📸 图像分析' : apiType === 'think' ? '🧠 深度思考' : '🔍 普通搜题';
      UI.setButtonState('loading');
      UI.showStatus(`${apiLabel}中...`);

      console.log('[PCAS][LOG] ===== analyzeCurrentPage 开始 =====');
      console.log('[PCAS][LOG] apiType:', apiType);

      try {
        const allQuestions = QuestionExtractor.extractAll();
        this._currentQuestions = allQuestions;

        console.log(`[PCAS][LOG] extractAll 提取到 ${allQuestions.length} 道题目`);
        allQuestions.forEach((q, i) => {
          console.log(`[PCAS][LOG]   题目${i + 1}: "${q.text.substring(0, 80)}..."`);
          console.log(`[PCAS][LOG]     选项数: ${q.options.length}, 输入框数: ${q.inputs.length}`);
          q.options.forEach((opt, j) => console.log(`[PCAS][LOG]       选项${String.fromCharCode(65 + j)}: "${opt.substring(0, 60)}"`));
          q.inputs.forEach((inp, j) => console.log(`[PCAS][LOG]       输入${j}: type=${inp.type}, tag=${inp.element?.tagName}, text="${(inp.optionText || '').substring(0, 30)}"`));
        });

        if (allQuestions.length === 0) {
          console.warn('[PCAS][LOG] 未找到任何题目，退出');
          UI.showToast('未找到题目，请选中题目后使用', 'error');
          return;
        }

        // 过滤掉已回答的题目
        const questions = allQuestions.filter(q => !this._answeredSet.has(this._hashQuestion(q.text)));
        const skipped = allQuestions.length - questions.length;
        console.log(`[PCAS][LOG] 过滤后: ${questions.length} 题待处理, ${skipped} 题已回答跳过`);

        if (questions.length === 0) {
          UI.showToast(`全部 ${allQuestions.length} 题已回答过`, 'success');
          return;
        }

        if (skipped > 0) {
          UI.updateStatus(`找到 ${allQuestions.length} 题，跳过已答 ${skipped} 题，待处理 ${questions.length} 题`);
        } else {
          UI.updateStatus(`找到 ${questions.length} 道题目`);
        }

        const totalQuestions = questions.length;

        let successCount = 0;
        let failedCount = 0;
        for (let i = 0; i < totalQuestions; i++) {
          if (!this._isProcessing) break;

          const q = questions[i];
          UI.updateStatus(`分析第 ${i + 1}/${totalQuestions} 题...`);
          console.log(`[PCAS][LOG] ===== 开始处理第 ${i + 1}/${totalQuestions} 题 =====`);
          console.log(`[PCAS][LOG]   题目: "${q.text.substring(0, 100)}"`);

          try {
            const result = await this.solveQuestion(q, apiType);
            console.log(`[PCAS][LOG]   solveQuestion 返回:`, result ? `answer="${result.answer}"` : 'null');

            if (result) {
              successCount++;
              failedCount = 0; // 成功后重置失败计数
              console.log(`[PCAS][LOG]   inputs 数量: ${q.inputs.length}`);
              if (q.inputs.length > 0) {
                const qType = q.questionType || (/多选/.test(q.text) ? 'multi' : /判断/.test(q.text) ? 'judge' : /编程|简答|论述|问答/.test(q.text) ? 'essay' : /填空/.test(q.text) ? 'fill' : 'single');
                console.log(`[PCAS][LOG]   开始填充, 类型: ${qType}, inputs:`, q.inputs.map(inp => inp.type));

                let filled = false;
                if (qType === 'fill' || qType === 'essay') {
                  // 填空题/编程题/简答题：逐个输入框填入答案
                  const answers = result.answer.split('|').map(a => a.trim());
                  console.log(`[PCAS][LOG]   ${qType === 'essay' ? '编程/简答' : '填空'}题答案拆分:`, answers, `输入框数: ${q.inputs.length}`);
                  for (let idx = 0; idx < q.inputs.length; idx++) {
                    const ans = answers[idx] || answers[0] || result.answer;
                    const inp = q.inputs[idx].element;
                    console.log(`[PCAS][LOG]   输入${idx + 1}: element=${inp?.tagName} ans="${ans.substring(0, 50)}"`);
                    if (inp) {
                      const ok = await AnswerFiller.fill(inp, ans);
                      filled = filled || ok;
                      console.log(`[PCAS][LOG]   输入${idx + 1} 结果: ${ok}`);
                    } else {
                      console.warn(`[PCAS][LOG]   输入${idx + 1}: element 为 null!`);
                    }
                  }
                } else {
                  // 选择题/判断题
                  const isMulti = qType === 'multi';
                  filled = await AnswerFiller.fillChoiceQuestion(q.inputs, result.answer, 300, isMulti);
                }
                console.log(`[PCAS][LOG]   fillChoiceQuestion 结果: ${filled}`);
                if (!filled) {
                  console.log(`[PCAS][LOG]   降级到普通填充, 目标元素: ${q.inputs[0].element?.tagName}`);
                  await AnswerFiller.fill(q.inputs[0].element, result.answer);
                }
              } else {
                console.warn(`[PCAS][LOG]   该题目没有 inputs，无法自动填充`);
              }
            }
          } catch (error) {
            if (error.name === 'AbortError') break;
            console.error(`[PCAS][LOG] 题目 ${i + 1} 分析失败:`, error);
            failedCount++;

            if (error.message.includes('429')) {
              const waitTime = Math.min(failedCount * 5000, 30000);
              UI.updateStatus(`请求过快，等待 ${waitTime / 1000} 秒...`);
              console.log(`[PCAS][LOG]   429 限流，等待 ${waitTime}ms`);
              await new Promise(resolve => setTimeout(resolve, waitTime));
            }
          }

          if (i < totalQuestions - 1 && this._isProcessing) {
            // 根据失败次数动态调整间隔，避免持续 429
            const delay = failedCount > 3 ? 5000 : failedCount > 0 ? 3000 : 2000;
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }

        console.log(`[PCAS][LOG] ===== 全部完成, 成功 ${successCount}/${totalQuestions} =====`);
        if (this._isProcessing) {
          if (successCount >= totalQuestions) {
            UI.setButtonState('success');
            UI.showToast(`全部完成！共 ${totalQuestions} 题`, 'success');
          } else {
            UI.setButtonState('success');
            UI.showToast(`题目尚未完成，请耐心等待（${successCount}/${totalQuestions}）`, 'info', 5000);
          }
        }

      } catch (error) {
        if (error.name !== 'AbortError') {
          console.error('[PCAS] 分析失败:', error);
          UI.setButtonState('error');
          UI.showToast(`失败: ${error.message}`, 'error');
        }
      } finally {
        this._isProcessing = false;
        abortController = null;
        UI.hideStatus();
      }
    },

    async analyzeSelected(apiType = 'normal') {
      const selection = window.getSelection();
      const selectedText = selection?.toString().trim();

      if (!selectedText || selectedText.length < 3) {
        UI.showToast('请先选中题目文本', 'error');
        return;
      }

      if (this._isProcessing) {
        UI.showToast('正在处理中，请稍候...', 'info');
        return;
      }

      this._isProcessing = true;
      abortController = new AbortController();

      const apiLabel = apiType === 'vision' ? '📸 图像分析' : apiType === 'think' ? '🧠 深度思考' : '🔍 普通搜题';
      UI.setButtonState('loading');
      UI.showStatus(`${apiLabel}中...`);

      try {
        const question = {
          text: selectedText,
          options: [],
          inputs: [],
          element: selection?.anchorNode?.parentElement,
          selector: null
        };

        let result = await this.solveQuestion(question, apiType);

        // 如果已搜索过（solveQuestion 返回 null），从缓存获取答案尝试填充
        if (!result && this._isProcessing) {
          const cacheKey = PCAS_Storage.generateCacheKey(question.text + '_' + apiType);
          const cached = await PCAS_Storage.getCachedAnswer(cacheKey);
          if (cached && cached.answer) {
            result = cached;
            console.log(`[PCAS][LOG]   已搜索过，从缓存获取答案: "${cached.answer}"`);
          }
        }

        if (result && this._isProcessing) {
          // 自动填入答案到最近的输入框
          await this.fillAnswerToNearestInput(result.answer);

          // 显示弹窗（隐藏填充按钮，显示解析）
          UI.showAnswerPopup(
            result.answer,
            result.explanation,
            result.thinking,
            null,
            false
          );
          UI.setButtonState('success');
        }

      } catch (error) {
        if (error.name !== 'AbortError') {
          console.error('[PCAS] 分析失败:', error);
          UI.setButtonState('error');
          UI.showToast(`失败: ${error.message}`, 'error');
        }
      } finally {
        this._isProcessing = false;
        abortController = null;
        UI.hideStatus();
      }
    },

    async screenshotAndAnalyze(apiType = 'vision') {
      if (this._isProcessing) {
        UI.showToast('正在处理中，请稍候...', 'info');
        return;
      }

      this._isProcessing = true;
      abortController = new AbortController();

      UI.setButtonState('loading');
      UI.showStatus('截图中...');

      chrome.runtime.sendMessage({ type: 'CAPTURE_TAB' }, async (response) => {
        if (response?.imageData) {
          UI.updateStatus('图像分析中...');

          try {
            const params = {
              mode: 'image',
              content: '',
              imageData: response.imageData,
              meta: { url: window.location.href, title: document.title }
            };

            const result = await PCAS_API.solveViaBackground(params, apiType);

            if (result && this._isProcessing) {
              UI.showAnswerPopup(
                result.answer,
                result.explanation,
                result.thinking,
                () => this.fillAnswerToNearestInput(result.answer)
              );
              UI.setButtonState('success');
            }
          } catch (error) {
            if (error.name !== 'AbortError') {
              UI.setButtonState('error');
              UI.showToast(`截图分析失败: ${error.message}`, 'error');
            }
          } finally {
            this._isProcessing = false;
            abortController = null;
            UI.hideStatus();
          }
        } else {
          this._isProcessing = false;
          abortController = null;
          UI.hideStatus();
          UI.setButtonState('error');
          UI.showToast('截图失败', 'error');
        }
      });
    },

    async autoFillAll() {
      // 如果没有题目，先分析页面
      if (this._currentQuestions.length === 0) {
        UI.showToast('请先分析页面题目，正在自动分析...', 'info');
        await this.analyzeCurrentPage('normal');
        // analyzeCurrentPage 已经会自动填充，所以直接返回
        return;
      }

      // 检查是否有已回答的题目
      const answeredQuestions = this._currentQuestions.filter(q => q._answer);
      if (answeredQuestions.length === 0) {
        UI.showToast('没有已获取答案的题目，请先分析页面', 'info');
        return;
      }

      UI.showToast('正在自动填充...', 'info');
      let fillCount = 0;

      for (const q of answeredQuestions) {
        if (q.inputs && q.inputs.length > 0) {
          for (const input of q.inputs) {
            try {
              await AnswerFiller.fill(input.element, q._answer);
              fillCount++;
            } catch (e) {
              console.warn('[PCAS] 填充失败:', e);
            }
          }
        }
      }

      UI.showToast(fillCount > 0 ? `已填充 ${fillCount} 个输入框` : '没有找到可填充的输入框', fillCount > 0 ? 'success' : 'error');
    },

    /** 切换自动搜题 */
    async toggleAutoSearch() {
      this._autoSearchEnabled = !this._autoSearchEnabled;
      const toggleEl = document.getElementById('pcas-auto-search-toggle');
      const btnEl = document.getElementById('pcas-auto-search-btn');

      if (this._autoSearchEnabled) {
        toggleEl.textContent = 'ON';
        toggleEl.classList.add('pcas-toggle-on');
        btnEl.classList.add('pcas-active');
        UI.showToast('自动搜题已开启', 'success');
        this.startAutoSearch();
      } else {
        toggleEl.textContent = 'OFF';
        toggleEl.classList.remove('pcas-toggle-on');
        btnEl.classList.remove('pcas-active');
        UI.showToast('自动搜题已关闭', 'info');
        this.stopAutoSearch();
      }

      // 保存状态到 storage
      await PCAS_Storage.setConfig({ autoSearch: this._autoSearchEnabled });
    },

    /** 启动自动搜题（页面加载时检测题目并自动搜索） */
    startAutoSearch() {
      if (this._autoSearchTimer) return;

      // 延迟 2 秒后开始首次检测，等待页面内容加载完成
      this._autoSearchTimer = setTimeout(async () => {
        if (!this._autoSearchEnabled) return;

        const allQuestions = QuestionExtractor.extractAll();
        const newQuestions = allQuestions.filter(q => !this._answeredSet.has(this._hashQuestion(q.text)));
        if (newQuestions.length > 0 && !this._isProcessing) {
          console.log(`[PCAS] 自动搜题：检测到 ${newQuestions.length} 道新题目`);
          UI.showToast(`检测到 ${newQuestions.length} 道新题目，开始搜题...`, 'info', 2000);
          await this.analyzeCurrentPage('normal');
        } else if (allQuestions.length > 0) {
          console.log(`[PCAS] 自动搜题：全部 ${allQuestions.length} 题已回答过`);
        }
      }, 2000);
    },

    /** 停止自动搜题 */
    stopAutoSearch() {
      if (this._autoSearchTimer) {
        clearTimeout(this._autoSearchTimer);
        this._autoSearchTimer = null;
      }
      if (this._autoSearchDebounce) {
        clearTimeout(this._autoSearchDebounce);
        this._autoSearchDebounce = null;
      }
    },

    /** 延迟触发自动搜题（用于 DOM 变化检测） */
    _debouncedAutoSearch() {
      if (!this._autoSearchEnabled || this._isProcessing) return;

      if (this._autoSearchDebounce) {
        clearTimeout(this._autoSearchDebounce);
      }

      this._autoSearchDebounce = setTimeout(async () => {
        if (!this._autoSearchEnabled || this._isProcessing) return;

        const questions = QuestionExtractor.extractAll();
        // 只在有未回答的题目时触发
        const unanswered = questions.filter(q => !this._answeredSet.has(this._hashQuestion(q.text)));
        if (unanswered.length > 0) {
          console.log(`[PCAS] DOM变化检测到 ${unanswered.length} 道新题目`);
          await this.analyzeCurrentPage('normal');
        }
      }, 3000); // 3 秒防抖
    },

    async showHistory() {
      await UI.showHistoryPanel();
    },

    async solveQuestion(question, apiType = 'normal') {
      const cacheKey = PCAS_Storage.generateCacheKey(question.text + '_' + apiType);
      const qHash = this._hashQuestion(question.text);

      console.log(`[PCAS][LOG] solveQuestion: "${question.text.substring(0, 60)}..."`);

      // 检查是否已在本次会话中回答过
      if (this._answeredSet.has(qHash)) {
        console.log('[PCAS][LOG]   → 跳过（已回答）');
        return null;
      }

      const config = await PCAS_Storage.getConfig(['cacheEnabled']);

      if (config.cacheEnabled) {
        const cached = await PCAS_Storage.getCachedAnswer(cacheKey);
        if (cached) {
          console.log(`[PCAS][LOG]   → 命中缓存, answer="${cached.answer}"`);
          this._answeredSet.add(qHash);
          question._answer = cached.answer;
          return cached;
        }
      }

      const params = {
        mode: 'text',
        content: question.text,
        options: question.options
      };

      console.log(`[PCAS][LOG]   → 发送 API 请求, options=${question.options.length} 个`);
      // 只通过 Background 调用（避免 CORS 问题）
      const result = await PCAS_API.solveViaBackground(params, apiType);

      console.log(`[PCAS][LOG]   → API 返回:`, result);
      if (result && result.answer) {
        console.log(`[PCAS][LOG]   → 答案: "${result.answer}"`);
        if (config.cacheEnabled) {
          await PCAS_Storage.setCachedAnswer(cacheKey, { ...result, apiType });
        }

        await PCAS_Storage.addHistory({
          question: question.text.substring(0, 200),
          answer: result.answer,
          url: window.location.href,
          type: apiType
        });

        question._answer = result.answer;
        this._answeredSet.add(qHash);
        UI.updateHistoryCount();
      }

      return result;
    },

    async fillAnswerToNearestInput(answer) {
      console.log(`[PCAS][LOG] fillAnswerToNearestInput: answer="${answer.substring(0, 30)}"`);

      // 提取答案字母
      const letters = AnswerFiller.extractAnswerLetters(answer);
      const firstLetter = letters[0] || null;

      // 1. 检查当前焦点元素
      const active = document.activeElement;
      console.log(`[PCAS][LOG]   step1 activeElement: tag=${active?.tagName} type=${active?.type} contentEditable=${active?.contentEditable}`);
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.contentEditable === 'true' || active.isContentEditable)) {
        // 如果焦点在 input 上，检查是否是 radio/checkbox（选择题）
        if (active.type === 'radio' || active.type === 'checkbox') {
          const group = active.form?.querySelectorAll(`input[name="${active.name}"]`) || document.querySelectorAll(`input[name="${active.name}"]`);
          if (firstLetter && group.length > 0) {
            const idx = firstLetter.charCodeAt(0) - 65;
            if (idx >= 0 && idx < group.length) {
              await AnswerFiller.simulateClick(group[idx]);
              UI.showToast('已点击选项', 'success');
              return;
            }
          }
        }
        console.log(`[PCAS][LOG]   → step1 填入焦点元素`);
        await AnswerFiller.fill(active, answer);
        UI.showToast('已填入答案', 'success');
        return;
      }

      // 2. 从选区向上查找，优先找选择题选项
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        const container = range.commonAncestorContainer;
        const parentEl = container.nodeType === 3 ? container.parentElement : container;
        console.log(`[PCAS][LOG]   step2 选区容器: tag=${parentEl?.tagName} class="${parentEl?.className?.substring(0, 40)}"`);

        // 从选区位置向上查找
        let current = parentEl;
        for (let depth = 0; depth < 10 && current; depth++) {
          // 优先查找选择题的 radio/checkbox 选项
          const radios = current.querySelectorAll?.('[role="radio"], [role="checkbox"], input[type="radio"], input[type="checkbox"]');
          if (radios && radios.length >= 2 && firstLetter) {
            const idx = firstLetter.charCodeAt(0) - 65;
            if (idx >= 0 && idx < radios.length) {
              console.log(`[PCAS][LOG]   → step2 找到选择题选项 (depth=${depth}), 点击 ${firstLetter}`);
              await AnswerFiller.simulateClick(radios[idx]);
              UI.showToast('已点击选项', 'success');
              return;
            }
          }

          // 查找普通 input/textarea（填空题）
          const inp = current.querySelector?.('input[type="text"], textarea');
          if (inp && inp.offsetParent !== null) {
            console.log(`[PCAS][LOG]   → step2 找到 input/textarea (depth=${depth})`);
            await AnswerFiller.fill(inp, answer);
            UI.showToast('已填入答案', 'success');
            return;
          }

          // 查找 UEditor iframe（填空/编程题）
          const iframe = current.querySelector?.('iframe');
          if (iframe) {
            try {
              const doc = iframe.contentDocument;
              if (doc && doc.body && doc.body.contentEditable === 'true') {
                // 检查这个 iframe 旁边是否有 radio 选项（说明是选择题区域）
                const nearbyRadios = current.parentElement?.querySelectorAll?.('[role="radio"], [role="checkbox"], input[type="radio"], input[type="checkbox"]');
                if (nearbyRadios && nearbyRadios.length >= 2 && firstLetter) {
                  // 这是选择题区域，不填 UEditor
                  console.log(`[PCAS][LOG]   → step2 跳过 UEditor（附近有选择题选项）`);
                } else {
                  console.log(`[PCAS][LOG]   → step2 找到 UEditor iframe (depth=${depth})`);
                  await AnswerFiller.fill(doc.body, answer);
                  UI.showToast('已填入答案', 'success');
                  return;
                }
              }
            } catch (e) {}
          }
          current = current.parentElement;
        }
      }

      // 3. 如果答案是选择题字母，在页面上找 radio/checkbox 选项点击
      if (firstLetter) {
        console.log(`[PCAS][LOG]   step3 查找页面 radio/checkbox`);
        const allRadios = document.querySelectorAll('[role="radio"], [role="checkbox"], input[type="radio"], input[type="checkbox"]');
        // 找到选区附近的 radio 组
        if (selection && selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          const selRect = range.getBoundingClientRect();
          // 按距离排序找最近的 radio
          const radioGroups = new Map();
          allRadios.forEach(r => {
            const name = r.name || r.getAttribute('role') || 'default';
            if (!radioGroups.has(name)) radioGroups.set(name, []);
            radioGroups.get(name).push(r);
          });
          for (const [, group] of radioGroups) {
            if (group.length < 2) continue;
            const groupRect = group[0].getBoundingClientRect();
            const dist = Math.abs(selRect.top - groupRect.top);
            if (dist < 500 && firstLetter) {
              const idx = firstLetter.charCodeAt(0) - 65;
              if (idx >= 0 && idx < group.length) {
                console.log(`[PCAS][LOG]   → step3 找到最近的选项组, 点击 ${firstLetter}`);
                await AnswerFiller.simulateClick(group[idx]);
                UI.showToast('已点击选项', 'success');
                return;
              }
            }
          }
        }
      }

      // 4. 查找页面上第一个空的可见输入框
      console.log(`[PCAS][LOG]   step4 扫描页面输入框`);
      const inputs = document.querySelectorAll('input[type="text"], textarea');
      for (const input of inputs) {
        if (!input.value && input.offsetParent !== null) {
          console.log(`[PCAS][LOG]   → step4 找到空输入框`);
          await AnswerFiller.fill(input, answer);
          UI.highlightElement(input);
          UI.showToast('已填入答案', 'success');
          return;
        }
      }

      // 5. 查找页面上第一个空的可见 UEditor iframe
      console.log(`[PCAS][LOG]   step5 扫描 UEditor iframe`);
      const iframes = document.querySelectorAll('iframe');
      for (const iframe of iframes) {
        try {
          const doc = iframe.contentDocument;
          if (doc && doc.body && doc.body.contentEditable === 'true') {
            const rect = iframe.getBoundingClientRect();
            const bodyText = doc.body.textContent?.trim() || '';
            if (rect.width > 50 && rect.height > 50 && !bodyText) {
              console.log(`[PCAS][LOG]   → step5 找到空 UEditor`);
              await AnswerFiller.fill(doc.body, answer);
              UI.showToast('已填入答案', 'success');
              return;
            }
          }
        } catch (e) {}
      }

      console.log(`[PCAS][LOG]   未找到任何可用输入框`);
      UI.showToast('未找到可用的输入框', 'error');
    }
  };

  // ============================================================
  // 监听消息
  // ============================================================
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'ANALYZE_PAGE':
        Core.analyzeCurrentPage(message.apiType || 'normal').then(() => sendResponse({ success: true }));
        return true;

      case 'ANALYZE_SELECTED':
        Core.analyzeSelected(message.apiType || 'normal').then(() => sendResponse({ success: true }));
        return true;

      case 'FILL_ANSWER':
        if (message.answer) {
          Core.fillAnswerToNearestInput(message.answer).then(() => sendResponse({ success: true }));
        }
        return true;

      case 'SCREENSHOT_ANALYZE':
        Core.screenshotAndAnalyze(message.apiType || 'vision').then(() => sendResponse({ success: true }));
        return true;

      case 'GET_PAGE_QUESTIONS':
        const questions = QuestionExtractor.extractAll();
        sendResponse({ questions: questions.map(q => ({ text: q.text, options: q.options })) });
        return false;

      case 'START_AUTO_SEARCH':
        Core._autoSearchEnabled = true;
        const toggleOn = document.getElementById('pcas-auto-search-toggle');
        const btnOn = document.getElementById('pcas-auto-search-btn');
        if (toggleOn) { toggleOn.textContent = 'ON'; toggleOn.classList.add('pcas-toggle-on'); }
        if (btnOn) btnOn.classList.add('pcas-active');
        Core.startAutoSearch();
        sendResponse({ success: true });
        return false;

      case 'STOP_AUTO_SEARCH':
        Core._autoSearchEnabled = false;
        const toggleOff = document.getElementById('pcas-auto-search-toggle');
        const btnOff = document.getElementById('pcas-auto-search-btn');
        if (toggleOff) { toggleOff.textContent = 'OFF'; toggleOff.classList.remove('pcas-toggle-on'); }
        if (btnOff) btnOff.classList.remove('pcas-active');
        Core.stopAutoSearch();
        sendResponse({ success: true });
        return false;
    }
  });

  // ============================================================
  // MutationObserver - 监听 DOM 变化，自动触发搜题
  // ============================================================
  const observer = new MutationObserver((mutations) => {
    const hasNewNodes = mutations.some(m => m.addedNodes.length > 0);
    if (!hasNewNodes) return;

    // 如果自动搜题已开启，检测是否有新的题目元素出现
    if (Core._autoSearchEnabled && !Core._isProcessing) {
      Core._debouncedAutoSearch();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // ============================================================
  // 初始化
  // ============================================================
  try {
    UI.init();
    UI.updateHistoryCount();

    // 恢复自动搜题状态
    PCAS_Storage.getConfig(['autoSearch']).then(config => {
      if (config.autoSearch) {
        Core._autoSearchEnabled = true;
        const toggleEl = document.getElementById('pcas-auto-search-toggle');
        const btnEl = document.getElementById('pcas-auto-search-btn');
        if (toggleEl) {
          toggleEl.textContent = 'ON';
          toggleEl.classList.add('pcas-toggle-on');
        }
        if (btnEl) {
          btnEl.classList.add('pcas-active');
        }
        Core.startAutoSearch();
        console.log('[PCAS] 自动搜题已恢复启用');
      }
    });

    console.log('[PCAS Plugin v2.0] 已加载');
  } catch (error) {
    console.error('[PCAS] 初始化失败:', error);
  }

})();
